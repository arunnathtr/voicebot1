# Feasibility Analytics System

A comprehensive digital solution for enhancing the feasibility assessment process in oncology clinical trials. This system enables digitization, centralization, and analysis of feasibility data collected from sponsors, CROs, and site investigators.

## 🚀 Features

### Core Modules
- **Document Management System (DMS)** - Upload and process PDF, Word, Excel, and image files with OCR
- **Feasibility Workflow Module** - Manage feasibility studies and site assessments
- **Survey Parser & Data Normalizer** - Convert unstructured responses to structured data
- **Analytics Dashboard** - Comprehensive insights and performance metrics
- **User Portal** - Role-based access control and authentication
- **Master Data Repository** - Oncology-specific datasets and information

### Key Capabilities
- ✅ **OCR Processing** - Extract text from scanned documents and images
- ✅ **File Upload** - Support for PDF, Word, Excel, and image formats
- ✅ **Data Analytics** - Interactive charts and performance metrics
- ✅ **User Management** - Role-based access control
- ✅ **Real-time Updates** - Live data synchronization
- ✅ **Responsive Design** - Mobile-friendly interface

## 🛠️ Technology Stack

### Frontend
- **React 18** - Modern UI framework
- **Tailwind CSS** - Utility-first CSS framework
- **Recharts** - Data visualization library
- **React Query** - Data fetching and caching
- **React Router** - Client-side routing
- **Lucide React** - Icon library

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web application framework
- **JWT** - Authentication and authorization
- **Multer** - File upload handling
- **Tesseract.js** - OCR processing
- **PDF-parse** - PDF text extraction

### Development Tools
- **Concurrently** - Run multiple commands
- **Nodemon** - Development server with auto-restart
- **ESLint** - Code linting
- **Prettier** - Code formatting

## 📦 Installation

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Quick Start

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd feasibility-analytics-system
   ```

2. **Install dependencies**
   ```bash
   # Install server dependencies
   npm install
   
   # Install client dependencies
   cd client
   npm install
   cd ..
   ```

3. **Start the development servers**
   ```bash
   # Start both server and client
   npm run dev
   
   # Or start them separately
   npm run server  # Backend on port 5000
   npm run client  # Frontend on port 3000
   ```

4. **Access the application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000
   - Health Check: http://localhost:5000/api/health

## 🔐 Authentication

### Demo Accounts
The system includes pre-configured demo accounts for testing:

| Email | Password | Role | Organization |
|-------|----------|------|--------------|
| `admin@feasibility.com` | `password` | Admin | Clinical Ops |
| `feasibility@feasibility.com` | `password` | Feasibility Manager | Feasibility Team |
| `site@feasibility.com` | `password` | Site Investigator | Research Site |

## 📊 Dashboard Features

### Key Metrics
- **Total Documents** - Track uploaded documents
- **Active Users** - Monitor system usage
- **Active Studies** - Current feasibility studies
- **Pending Reviews** - Items requiring attention

### Analytics
- **Recruitment Trends** - Projected vs actual patient recruitment
- **Site Performance** - Site-wise success rates and efficiency
- **Disease Distribution** - Oncology focus areas
- **Geographic Analysis** - Regional study distribution

## 📁 Document Management

### Supported Formats
- **PDF** - Protocol documents, feasibility surveys
- **Word** - Reports, questionnaires
- **Excel** - Data sheets, patient lists
- **Images** - Scanned forms, handwritten notes

### OCR Capabilities
- Text extraction from scanned documents
- Handwritten text recognition
- Multi-language support
- Automatic metadata extraction

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `GET /api/auth/profile` - Get user profile
- `POST /api/auth/logout` - User logout

### Documents
- `GET /api/documents` - List documents
- `POST /api/documents/upload` - Upload document
- `GET /api/documents/:id` - Get document details
- `DELETE /api/documents/:id` - Delete document
- `GET /api/documents/search/text` - Search documents

### Feasibility
- `GET /api/feasibility` - List feasibility studies
- `POST /api/feasibility` - Create new study
- `PUT /api/feasibility/:id` - Update study
- `DELETE /api/feasibility/:id` - Delete study

### Analytics
- `GET /api/analytics/dashboard` - Dashboard statistics
- `GET /api/analytics/recruitment-trends` - Recruitment data
- `GET /api/analytics/site-performance` - Site performance
- `GET /api/analytics/disease-distribution` - Disease data

## 🚀 Deployment

### Production Build
```bash
# Build the React application
cd client
npm run build

# Start production server
cd ..
npm start
```

### Environment Variables
Create a `.env` file in the root directory:
```env
NODE_ENV=production
PORT=5000
JWT_SECRET=your-secret-key
CLIENT_URL=http://localhost:3000
```

## 📈 Performance Metrics

### System Requirements
- **CPU**: 2+ cores
- **RAM**: 4GB minimum, 8GB recommended
- **Storage**: 10GB for application + document storage
- **Network**: Stable internet connection for file uploads

### Expected Performance
- **Response Time**: < 2 seconds for dashboard loads
- **File Upload**: Up to 50MB per file
- **OCR Processing**: 30-60 seconds per document
- **Concurrent Users**: 50+ simultaneous users

## 🔒 Security Features

- **JWT Authentication** - Secure token-based auth
- **Role-based Access** - Granular permissions
- **File Validation** - Type and size restrictions
- **Input Sanitization** - XSS protection
- **CORS Configuration** - Cross-origin security
- **Rate Limiting** - API abuse prevention

## 🧪 Testing

### Run Tests
```bash
# Run all tests
npm test

# Run tests with coverage
npm run test:coverage

# Run linting
npm run lint
```

## 📝 Development

### Project Structure
```
feasibility-analytics-system/
├── server/                 # Backend API
│   ├── routes/            # API routes
│   ├── uploads/           # File storage
│   └── index.js           # Server entry point
├── client/                # Frontend React app
│   ├── src/
│   │   ├── components/    # React components
│   │   ├── contexts/      # React contexts
│   │   └── App.js         # Main app component
│   └── public/            # Static assets
├── package.json           # Root dependencies
└── README.md             # This file
```

### Adding New Features
1. Create new route in `server/routes/`
2. Add corresponding React component in `client/src/components/`
3. Update navigation in `Layout.js`
4. Add API calls in the component
5. Test thoroughly

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- **Email**: support@feasibility.com
- **Documentation**: [Wiki](https://github.com/your-repo/wiki)
- **Issues**: [GitHub Issues](https://github.com/your-repo/issues)

## 🗺️ Roadmap

### Phase 1 (Current)
- ✅ Basic document management
- ✅ User authentication
- ✅ Dashboard analytics
- ✅ Feasibility workflow

### Phase 2 (Next)
- 🔄 Advanced OCR with AI
- 🔄 Real-time collaboration
- 🔄 Mobile application
- 🔄 Advanced reporting

### Phase 3 (Future)
- 🔄 CTMS integration
- 🔄 Machine learning insights
- 🔄 Multi-language support
- 🔄 Advanced security features

---

**Built with ❤️ for the clinical research community** 