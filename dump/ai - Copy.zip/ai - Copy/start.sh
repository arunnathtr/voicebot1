#!/bin/bash

echo "Starting Feasibility Analytics System..."
echo

echo "Installing dependencies..."
npm install
cd client
npm install
cd ..

echo
echo "Starting development servers..."
echo "Frontend will be available at: http://localhost:3000"
echo "Backend API will be available at: http://localhost:5000"
echo

npm run dev 