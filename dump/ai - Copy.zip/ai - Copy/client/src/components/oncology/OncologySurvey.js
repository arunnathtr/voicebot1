import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';
import { 
  FileText,
  Save,
  Upload,
  Download,
  CheckCircle,
  AlertCircle,
  Activity
} from 'lucide-react';
import toast from 'react-hot-toast';

const OncologySurvey = () => {
  const [activeTab, setActiveTab] = useState('survey');
  const [surveyData, setSurveyData] = useState({
    cancerType: 'locally advanced or metastatic gastric and gastroesophageal junction cancer',
    totalPatients: 12,
    her2Positive: 7,
    her2LowNegative: 5,
    her2PositivePDL1High: 3,
    her2LowNegativePDL1Low: 2,
    her2LowNegativePDL1High: 1,
    comments: ''
  });

  const queryClient = useQueryClient();

  // Mock survey data
  const { data: surveyHistory } = useQuery('oncology-survey-history', async () => {
    return {
      surveys: [
        {
          id: 1,
          siteId: 'SITE-001',
          siteName: 'Memorial Sloan Kettering Cancer Center',
          cancerType: 'locally advanced or metastatic gastric and gastroesophageal junction cancer',
          totalPatients: 12,
          her2Positive: 7,
          her2LowNegative: 5,
          her2PositivePDL1High: 3,
          her2LowNegativePDL1Low: 2,
          her2LowNegativePDL1High: 1,
          submittedDate: '2024-01-15',
          status: 'completed'
        },
        {
          id: 2,
          siteId: 'SITE-002',
          siteName: 'MD Anderson Cancer Center',
          cancerType: 'locally advanced or metastatic gastric and gastroesophageal junction cancer',
          totalPatients: 8,
          her2Positive: 3,
          her2LowNegative: 5,
          her2PositivePDL1High: 1,
          her2LowNegativePDL1Low: 3,
          her2LowNegativePDL1High: 2,
          submittedDate: '2024-01-10',
          status: 'completed'
        }
      ]
    };
  });

  const submitMutation = useMutation(
    async (data) => {
      const response = await axios.post('/api/oncology/survey', data);
      return response.data;
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries('oncology-survey-history');
        toast.success('Survey submitted successfully');
        setSurveyData({
          cancerType: 'locally advanced or metastatic gastric and gastroesophageal junction cancer',
          totalPatients: 0,
          her2Positive: 0,
          her2LowNegative: 0,
          her2PositivePDL1High: 0,
          her2LowNegativePDL1Low: 0,
          her2LowNegativePDL1High: 0,
          comments: ''
        });
      },
      onError: (error) => {
        toast.error(error.response?.data?.error || 'Failed to submit survey');
      }
    }
  );

  const handleInputChange = (field, value) => {
    setSurveyData(prev => ({
      ...prev,
      [field]: parseInt(value) || 0
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validation
    if (surveyData.her2Positive + surveyData.her2LowNegative !== surveyData.totalPatients) {
      toast.error('HER2 positive and low/negative patients must sum to total patients');
      return;
    }
    
    if (surveyData.her2PositivePDL1High > surveyData.her2Positive) {
      toast.error('HER2 positive with PD-L1≥1% cannot exceed total HER2 positive patients');
      return;
    }
    
    if (surveyData.her2LowNegativePDL1Low + surveyData.her2LowNegativePDL1High > surveyData.her2LowNegative) {
      toast.error('HER2 low/negative PD-L1 categories cannot exceed total HER2 low/negative patients');
      return;
    }

    submitMutation.mutate(surveyData);
  };

  const calculateValidation = () => {
    const her2Sum = surveyData.her2Positive + surveyData.her2LowNegative;
    const pdl1Sum = surveyData.her2LowNegativePDL1Low + surveyData.her2LowNegativePDL1High;
    
    return {
      her2Valid: her2Sum === surveyData.totalPatients,
      pdl1Valid: pdl1Sum <= surveyData.her2LowNegative,
      her2PositiveValid: surveyData.her2PositivePDL1High <= surveyData.her2Positive
    };
  };

  const validation = calculateValidation();

  const getValidationColor = (isValid) => {
    return isValid ? 'text-green-600' : 'text-red-600';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Oncology Survey</h1>
          <p className="mt-1 text-sm text-gray-500">
            Capture detailed patient population data for oncology feasibility studies
          </p>
        </div>
        <div className="flex space-x-2">
          <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 flex items-center space-x-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </button>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center space-x-2">
            <Upload className="h-4 w-4" />
            <span>Import</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('survey')}
              className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                activeTab === 'survey'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <FileText className="h-4 w-4" />
              <span>Survey Form</span>
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                activeTab === 'history'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Activity className="h-4 w-4" />
              <span>Survey History</span>
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'survey' && (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Cancer Type */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Cancer Type</h3>
                <p className="text-sm text-gray-600">
                  {surveyData.cancerType}
                </p>
              </div>

              {/* Question 6 */}
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Question 6</h3>
                <p className="text-sm text-gray-600 mb-4">
                  How many patients were newly diagnosed as <strong>locally advanced or metastatic gastric and gastroesophageal junction cancer</strong> in the last 12 months at your site (i.e., under your direct medical care)
                </p>
                <div className="flex items-center space-x-4">
                  <input
                    type="number"
                    value={surveyData.totalPatients}
                    onChange={(e) => handleInputChange('totalPatients', e.target.value)}
                    className="w-32 border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                    min="0"
                  />
                  <span className="text-sm text-gray-500">patients</span>
                </div>
              </div>

              {/* Question 7 */}
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Question 7</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Among the patient population in Q6, how many patients meet the following criteria:
                </p>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">a. HER2 positive:</span>
                    <div className="flex items-center space-x-4">
                      <input
                        type="number"
                        value={surveyData.her2Positive}
                        onChange={(e) => handleInputChange('her2Positive', e.target.value)}
                        className="w-32 border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                        min="0"
                      />
                      <span className="text-sm text-gray-500">patients</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">b. HER2 low/negative:</span>
                    <div className="flex items-center space-x-4">
                      <input
                        type="number"
                        value={surveyData.her2LowNegative}
                        onChange={(e) => handleInputChange('her2LowNegative', e.target.value)}
                        className="w-32 border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                        min="0"
                      />
                      <span className="text-sm text-gray-500">patients</span>
                    </div>
                  </div>
                  <div className={`text-sm ${getValidationColor(validation.her2Valid)}`}>
                    {validation.her2Valid ? (
                      <span className="flex items-center">
                        <CheckCircle className="h-4 w-4 mr-1" />
                        HER2 categories sum to total patients ✓
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <AlertCircle className="h-4 w-4 mr-1" />
                        HER2 categories must sum to {surveyData.totalPatients} patients
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Question 8 */}
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Question 8</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Among the patient population in Q7a, how many patients meet the following criteria:
                </p>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">HER2 positive with PD-L1≥1%:</span>
                    <div className="flex items-center space-x-4">
                      <input
                        type="number"
                        value={surveyData.her2PositivePDL1High}
                        onChange={(e) => handleInputChange('her2PositivePDL1High', e.target.value)}
                        className="w-32 border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                        min="0"
                        max={surveyData.her2Positive}
                      />
                      <span className="text-sm text-gray-500">patients</span>
                    </div>
                  </div>
                  <div className={`text-sm ${getValidationColor(validation.her2PositiveValid)}`}>
                    {validation.her2PositiveValid ? (
                      <span className="flex items-center">
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Valid (≤ {surveyData.her2Positive} HER2 positive patients) ✓
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <AlertCircle className="h-4 w-4 mr-1" />
                        Cannot exceed {surveyData.her2Positive} HER2 positive patients
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Question 9 */}
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Question 9</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Among the patient population in Q7b, how many patients meet the following criteria:
                </p>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">a. HER2 low/negative with PD-L1 &lt;1%:</span>
                    <div className="flex items-center space-x-4">
                      <input
                        type="number"
                        value={surveyData.her2LowNegativePDL1Low}
                        onChange={(e) => handleInputChange('her2LowNegativePDL1Low', e.target.value)}
                        className="w-32 border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                        min="0"
                      />
                      <span className="text-sm text-gray-500">patients</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">b. HER2 low/negative with PD-L1≥1%:</span>
                    <div className="flex items-center space-x-4">
                      <input
                        type="number"
                        value={surveyData.her2LowNegativePDL1High}
                        onChange={(e) => handleInputChange('her2LowNegativePDL1High', e.target.value)}
                        className="w-32 border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                        min="0"
                      />
                      <span className="text-sm text-gray-500">patients</span>
                    </div>
                  </div>
                  <div className={`text-sm ${getValidationColor(validation.pdl1Valid)}`}>
                    {validation.pdl1Valid ? (
                      <span className="flex items-center">
                        <CheckCircle className="h-4 w-4 mr-1" />
                        PD-L1 categories valid (≤ {surveyData.her2LowNegative} HER2 low/negative patients) ✓
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <AlertCircle className="h-4 w-4 mr-1" />
                        PD-L1 categories cannot exceed {surveyData.her2LowNegative} HER2 low/negative patients
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="text-lg font-medium text-blue-900 mb-4">Data Summary</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-900">{surveyData.totalPatients}</div>
                    <div className="text-sm text-blue-600">Total Patients</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-900">{surveyData.her2Positive}</div>
                    <div className="text-sm text-green-600">HER2 Positive</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-900">{surveyData.her2LowNegative}</div>
                    <div className="text-sm text-orange-600">HER2 Low/Negative</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-900">
                      {surveyData.her2PositivePDL1High + surveyData.her2LowNegativePDL1High}
                    </div>
                    <div className="text-sm text-purple-600">PD-L1≥1%</div>
                  </div>
                </div>
              </div>

              {/* Comments */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Additional Comments</label>
                <textarea
                  value={surveyData.comments}
                  onChange={(e) => setSurveyData(prev => ({ ...prev, comments: e.target.value }))}
                  rows={3}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter any additional comments or notes..."
                />
              </div>

              {/* Submit Button */}
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={submitMutation.isLoading || !validation.her2Valid || !validation.pdl1Valid || !validation.her2PositiveValid}
                  className="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                >
                  <Save className="h-4 w-4" />
                  <span>{submitMutation.isLoading ? 'Submitting...' : 'Submit Survey'}</span>
                </button>
              </div>
            </form>
          )}

          {activeTab === 'history' && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Survey History</h3>
              {surveyHistory?.surveys.map((survey) => (
                <div key={survey.id} className="bg-white border border-gray-200 rounded-lg p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900">{survey.siteName}</h4>
                      <p className="text-sm text-gray-500">{survey.siteId}</p>
                    </div>
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      {survey.status}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-lg font-bold text-gray-900">{survey.totalPatients}</div>
                      <div className="text-xs text-gray-500">Total Patients</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-green-600">{survey.her2Positive}</div>
                      <div className="text-xs text-gray-500">HER2 Positive</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-orange-600">{survey.her2LowNegative}</div>
                      <div className="text-xs text-gray-500">HER2 Low/Negative</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-purple-600">
                        {survey.her2PositivePDL1High + survey.her2LowNegativePDL1High}
                      </div>
                      <div className="text-xs text-gray-500">PD-L1≥1%</div>
                    </div>
                  </div>
                  
                  <div className="text-xs text-gray-500">
                    Submitted: {new Date(survey.submittedDate).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default OncologySurvey; 