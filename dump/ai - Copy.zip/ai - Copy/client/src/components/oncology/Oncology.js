import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';

import { 
  Plus, 
  Search, 
  Filter, 
  User,
  Building,
  CheckCircle,
  Activity,
  TestTube,
  Pill,
  MapPin,
  TrendingUp,
  FileText
} from 'lucide-react';
import toast from 'react-hot-toast';
import OncologySurvey from './OncologySurvey';

const Oncology = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDisease, setSelectedDisease] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const queryClient = useQueryClient();

  // Fetch oncology studies
  const { data: oncologyData, isLoading } = useQuery('oncology-studies', async () => {
    const response = await axios.get('/api/oncology');
    return response.data;
  });

  // Fetch oncology analytics
  const { data: analyticsData } = useQuery('oncology-analytics', async () => {
    const response = await axios.get('/api/oncology/analytics/summary');
    return response.data;
  });

  // Fetch standard of care data
  const { data: socData } = useQuery(['oncology-soc', selectedDisease], async () => {
    const response = await axios.get(`/api/oncology/standard-of-care?disease=${selectedDisease}`);
    return response.data;
  });

  // Fetch biomarker data
  const { data: biomarkerData } = useQuery(['oncology-biomarkers', selectedDisease], async () => {
    const response = await axios.get(`/api/oncology/biomarkers?disease=${selectedDisease}`);
    return response.data;
  });

  // Fetch prevalence data
  const { data: prevalenceData } = useQuery(['oncology-prevalence', selectedDisease], async () => {
    const response = await axios.get(`/api/oncology/prevalence?disease=${selectedDisease}`);
    return response.data;
  });

  const createMutation = useMutation(
    async (data) => {
      const response = await axios.post('/api/oncology', data);
      return response.data;
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries('oncology-studies');
        toast.success('Oncology study created successfully');
        setShowForm(false);
      },
      onError: (error) => {
        toast.error(error.response?.data?.error || 'Failed to create study');
      }
    }
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      studyId: formData.get('studyId'),
      disease: formData.get('disease'),
      country: formData.get('country'),
      sites: []
    };
    createMutation.mutate(data);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getProgressColor = (progress) => {
    if (progress >= 80) return 'bg-green-500';
    if (progress >= 60) return 'bg-yellow-500';
    if (progress >= 40) return 'bg-orange-500';
    return 'bg-red-500';
  };

  if (isLoading) return <div>Loading oncology data...</div>;

  const filteredStudies = oncologyData?.studies?.filter(study => {
    const matchesSearch = !searchQuery || 
      study.studyId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      study.disease.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDisease = !selectedDisease || study.disease === selectedDisease;
    const matchesCountry = !selectedCountry || study.country === selectedCountry;
    return matchesSearch && matchesDisease && matchesCountry;
  }) || [];

  const diseases = [...new Set(oncologyData?.studies?.map(s => s.disease) || [])];
  const countries = [...new Set(oncologyData?.studies?.map(s => s.country) || [])];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Oncology Feasibility</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage oncology-specific feasibility studies and site assessments
          </p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>New Oncology Study</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-4 rounded-lg shadow">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search studies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={selectedDisease}
              onChange={(e) => setSelectedDisease(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="">All Diseases</option>
              {diseases.map(disease => (
                <option key={disease} value={disease}>{disease}</option>
              ))}
            </select>
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="">All Countries</option>
              {countries.map(country => (
                <option key={country} value={country}>{country}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 px-6">
            {[
              { id: 'overview', name: 'Overview', icon: Activity },
              { id: 'soc', name: 'Standard of Care', icon: Pill },
              { id: 'biomarkers', name: 'Biomarkers', icon: TestTube },
              { id: 'prevalence', name: 'Prevalence', icon: TrendingUp },
              { id: 'survey', name: 'Survey', icon: FileText }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.id
                      ? 'border-indigo-500 text-indigo-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Analytics Summary */}
              {analyticsData && (
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="flex items-center">
                      <Activity className="h-8 w-8 text-blue-600" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-blue-600">Total Studies</p>
                        <p className="text-2xl font-bold text-blue-900">{analyticsData.totalStudies}</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="flex items-center">
                      <Building className="h-8 w-8 text-green-600" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-green-600">Total Sites</p>
                        <p className="text-2xl font-bold text-green-900">{analyticsData.totalSites}</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <div className="flex items-center">
                      <User className="h-8 w-8 text-purple-600" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-purple-600">Projected Patients</p>
                        <p className="text-2xl font-bold text-purple-900">{analyticsData.recruitmentStats?.projected}</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <div className="flex items-center">
                      <CheckCircle className="h-8 w-8 text-orange-600" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-orange-600">Actual Patients</p>
                        <p className="text-2xl font-bold text-orange-900">{analyticsData.recruitmentStats?.actual}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Studies Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredStudies.map((study) => (
                  <div key={study.id} className="bg-white rounded-lg shadow hover:shadow-md transition-shadow border">
                    <div className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{study.studyId}</h3>
                          <p className="text-sm text-gray-500">{study.disease}</p>
                          <p className="text-xs text-gray-400">{study.country}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <MapPin className="h-4 w-4 text-gray-400" />
                          <span className="text-sm text-gray-500">{study.sites.length} sites</span>
                        </div>
                      </div>

                      {/* Sites */}
                      <div className="space-y-3">
                        {study.sites.map((site) => (
                          <div key={site.id} className="border-l-4 border-indigo-500 pl-4 py-2">
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="text-sm font-medium text-gray-900">{site.name}</h4>
                                <p className="text-xs text-gray-500">{site.investigator}</p>
                              </div>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(site.status)}`}>
                                {site.status}
                              </span>
                            </div>
                            
                            {/* Recruitment Progress */}
                            <div className="mt-2">
                              <div className="flex justify-between text-xs text-gray-500 mb-1">
                                <span>Recruitment: {site.actualRecruitment}/{site.recruitmentProjection}</span>
                                <span>{Math.round((site.actualRecruitment / site.recruitmentProjection) * 100)}%</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2">
                                <div
                                  className={`h-2 rounded-full ${getProgressColor((site.actualRecruitment / site.recruitmentProjection) * 100)}`}
                                  style={{ width: `${(site.actualRecruitment / site.recruitmentProjection) * 100}%` }}
                                ></div>
                              </div>
                            </div>

                            {/* Quick Info */}
                            <div className="mt-2 flex flex-wrap gap-1">
                              {site.biomarkers?.slice(0, 3).map((biomarker, index) => (
                                <span key={index} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                  {biomarker}
                                </span>
                              ))}
                              {site.biomarkers?.length > 3 && (
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                  +{site.biomarkers.length - 3} more
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'soc' && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Standard of Care & Drug Information</h3>
              {socData?.standardOfCare?.map((study) => (
                <div key={study.studyId} className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">{study.studyId} - {study.disease}</h4>
                  {study.sites.map((site) => (
                    <div key={site.siteId} className="ml-4 mb-4 p-3 bg-white rounded border">
                      <h5 className="font-medium text-gray-800 mb-2">{site.siteName}</h5>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium text-gray-700">Standard of Care:</p>
                          <p className="text-sm text-gray-600">{site.standardOfCare}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-700">Investigational Drugs:</p>
                          {site.investigationalDrugs?.map((drug, index) => (
                            <div key={index} className="text-sm text-gray-600">
                              <span className="font-medium">{drug.name}</span> - {drug.mechanismOfAction}
                              <br />
                              <span className="text-xs text-gray-500">Reimbursement: {drug.reimbursement}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}

          {activeTab === 'biomarkers' && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Biomarker & Laboratory Assessment</h3>
              {biomarkerData?.biomarkers?.map((study) => (
                <div key={study.studyId} className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">{study.studyId} - {study.disease}</h4>
                  {study.sites.map((site) => (
                    <div key={site.siteId} className="ml-4 mb-4 p-3 bg-white rounded border">
                      <h5 className="font-medium text-gray-800 mb-2">{site.siteName}</h5>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium text-gray-700">Biomarkers:</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {site.biomarkers?.map((biomarker, index) => (
                              <span key={index} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                {biomarker}
                              </span>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-700">Lab Assessments:</p>
                          <div className="text-sm text-gray-600 mt-1">
                            <p><span className="font-medium">Routine:</span> {site.labAssessments?.routine?.join(', ')}</p>
                            <p><span className="font-medium">Not Routine:</span> {site.labAssessments?.notRoutine?.join(', ')}</p>
                            <p><span className="font-medium">Local:</span> {site.labAssessments?.local?.join(', ')}</p>
                            <p><span className="font-medium">Outsource:</span> {site.labAssessments?.outsource?.join(', ')}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}

          {activeTab === 'prevalence' && (
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Prevalence & Epidemiology</h3>
              {prevalenceData?.prevalence?.map((study) => (
                <div key={study.studyId} className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">{study.studyId} - {study.disease}</h4>
                  {study.sites.map((site) => (
                    <div key={site.siteId} className="ml-4 mb-4 p-3 bg-white rounded border">
                      <h5 className="font-medium text-gray-800 mb-2">{site.siteName}</h5>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <p className="text-sm font-medium text-gray-700">General Prevalence:</p>
                          <p className="text-sm text-gray-600">{site.prevalence?.general}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-700">Treatment Prevalence:</p>
                          <p className="text-sm text-gray-600">{site.prevalence?.treatment}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-700">Mutation Prevalence:</p>
                          <p className="text-sm text-gray-600">{site.prevalence?.mutation}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}

          {activeTab === 'survey' && (
            <OncologySurvey />
          )}
        </div>
      </div>

      {/* New Study Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">New Oncology Study</h3>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Study ID</label>
                  <input
                    type="text"
                    name="studyId"
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Disease</label>
                  <input
                    type="text"
                    name="disease"
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Country</label>
                  <input
                    type="text"
                    name="country"
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={createMutation.isLoading}
                    className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 disabled:opacity-50"
                  >
                    {createMutation.isLoading ? 'Creating...' : 'Create Study'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Oncology; 