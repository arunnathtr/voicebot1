import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';
import { 
  FileText,
  Save,
  Eye,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import toast from 'react-hot-toast';

const SurveyIntake = () => {
  const [activeTab, setActiveTab] = useState('manual-entry');
  const [formData, setFormData] = useState({
    standardOfCare: '',
    investigationalDrug: '',
    biomarkers: '',
    prevalence: ''
  });
  const [normalizedData, setNormalizedData] = useState(null);

  // Mock survey inbox data
  const { data: surveyInbox } = useQuery('survey-inbox', async () => {
    return {
      surveys: [
        {
          id: 1,
          siteName: 'Memorial Sloan Kettering Cancer Center',
          disease: 'Non-small cell lung cancer',
          submittedDate: '2024-01-15',
          status: 'pending',
          priority: 'high'
        },
        {
          id: 2,
          siteName: 'MD Anderson Cancer Center',
          disease: 'Breast cancer',
          submittedDate: '2024-01-14',
          status: 'processed',
          priority: 'medium'
        },
        {
          id: 3,
          siteName: 'Dana-Farber Cancer Institute',
          disease: 'Colorectal cancer',
          submittedDate: '2024-01-13',
          status: 'pending',
          priority: 'low'
        }
      ]
    };
  });

  // Mock OCR results
  const { data: ocrResults } = useQuery('ocr-results', async () => {
    return {
      results: [
        {
          id: 1,
          fileName: 'feasibility_survey_001.pdf',
          extractedText: 'Standard of Care: Platinum-based chemotherapy\nInvestigational Drug: Pembrolizumab\nBiomarkers: PD-L1, EGFR\nPrevalence: 15% of lung cancer cases',
          confidence: 0.92,
          status: 'reviewed'
        },
        {
          id: 2,
          fileName: 'survey_response_002.pdf',
          extractedText: 'Standard of Care: Taxane-based therapy\nInvestigational Drug: Trastuzumab\nBiomarkers: HER2\nPrevalence: 8% of breast cancer cases',
          confidence: 0.87,
          status: 'pending'
        }
      ]
    };
  });

  const processMutation = useMutation(
    async (data) => {
      const response = await axios.post('/api/surveys/process', data);
      return response.data;
    },
    {
      onSuccess: (data) => {
        setNormalizedData(data.normalized);
        toast.success('Data processed successfully');
      },
      onError: (error) => {
        toast.error(error.response?.data?.error || 'Processing failed');
      }
    }
  );

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleProcessData = () => {
    if (!formData.standardOfCare && !formData.investigationalDrug && 
        !formData.biomarkers && !formData.prevalence) {
      toast.error('Please enter at least one field');
      return;
    }
    
    processMutation.mutate(formData);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'processed': return 'bg-green-100 text-green-800';
      case 'reviewed': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Main Page Title */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Feasibility Survey Intake</h1>
        </div>

        {/* Sub-Navigation Tabs */}
        <div className="border-b border-gray-200 mb-8">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('survey-inbox')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'survey-inbox'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Survey Inbox
            </button>
            <button
              onClick={() => setActiveTab('manual-entry')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'manual-entry'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Manual Entry
            </button>
            <button
              onClick={() => setActiveTab('ocr-results')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'ocr-results'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              OCR Results
            </button>
          </nav>
        </div>

        {/* Main Content Area */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Section - Data Input Forms */}
          <div className="space-y-6">
            {activeTab === 'manual-entry' && (
              <>
                <div className="bg-white p-6 rounded-lg shadow">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Data Input</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Standard of Care
                      </label>
                      <input
                        type="text"
                        value={formData.standardOfCare}
                        onChange={(e) => handleInputChange('standardOfCare', e.target.value)}
                        placeholder="Protocol"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Investigational Drug
                      </label>
                      <input
                        type="text"
                        value={formData.investigationalDrug}
                        onChange={(e) => handleInputChange('investigationalDrug', e.target.value)}
                        placeholder="Drug reimbursement"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Biomarkers
                      </label>
                      <input
                        type="text"
                        value={formData.biomarkers}
                        onChange={(e) => handleInputChange('biomarkers', e.target.value)}
                        placeholder="Lab assessments"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Prevalence
                      </label>
                      <input
                        type="text"
                        value={formData.prevalence}
                        onChange={(e) => handleInputChange('prevalence', e.target.value)}
                        placeholder="Recruitment Projection"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                      />
                    </div>
                    <div className="pt-4 border-t border-gray-200">
                      <button
                        onClick={handleProcessData}
                        disabled={processMutation.isLoading}
                        className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50 flex items-center space-x-2"
                      >
                        <Save className="h-4 w-4" />
                        <span>{processMutation.isLoading ? 'Processing...' : 'Process Data'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}

            {activeTab === 'survey-inbox' && (
              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Survey Inbox</h3>
                <div className="space-y-4">
                  {surveyInbox?.surveys.map((survey) => (
                    <div key={survey.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium text-gray-900">{survey.siteName}</h4>
                        <div className="flex space-x-2">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(survey.status)}`}>
                            {survey.status}
                          </span>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(survey.priority)}`}>
                            {survey.priority}
                          </span>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{survey.disease}</p>
                      <p className="text-xs text-gray-500">Submitted: {survey.submittedDate}</p>
                      <div className="mt-3 flex space-x-2">
                        <button className="text-sm text-indigo-600 hover:text-indigo-800 flex items-center space-x-1">
                          <Eye className="h-4 w-4" />
                          <span>View</span>
                        </button>
                        <button className="text-sm text-green-600 hover:text-green-800 flex items-center space-x-1">
                          <CheckCircle className="h-4 w-4" />
                          <span>Process</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'ocr-results' && (
              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="text-lg font-medium text-gray-900 mb-4">OCR Results</h3>
                <div className="space-y-4">
                  {ocrResults?.results.map((result) => (
                    <div key={result.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium text-gray-900">{result.fileName}</h4>
                        <div className="flex items-center space-x-2">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(result.status)}`}>
                            {result.status}
                          </span>
                          <span className="text-xs text-gray-500">
                            {Math.round(result.confidence * 100)}% confidence
                          </span>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-3 rounded text-sm text-gray-700 mb-3">
                        <p className="font-medium mb-1">Extracted Text:</p>
                        <p className="text-xs">{result.extractedText}</p>
                      </div>
                      <div className="flex space-x-2">
                        <button className="text-sm text-indigo-600 hover:text-indigo-800 flex items-center space-x-1">
                          <Eye className="h-4 w-4" />
                          <span>Review</span>
                        </button>
                        <button className="text-sm text-green-600 hover:text-green-800 flex items-center space-x-1">
                          <CheckCircle className="h-4 w-4" />
                          <span>Accept</span>
                        </button>
                        <button className="text-sm text-red-600 hover:text-red-800 flex items-center space-x-1">
                          <AlertCircle className="h-4 w-4" />
                          <span>Reject</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Section - Data Normalization/Preview */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Data Normalization</h3>
            <div className="border border-gray-200 rounded-lg p-4 min-h-[400px]">
              {normalizedData ? (
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 mb-4">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="text-sm font-medium text-green-800">Data Successfully Normalized</span>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-500">Standard of Care</label>
                      <p className="text-sm text-gray-900">{normalizedData.standardOfCare}</p>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-500">Investigational Drug</label>
                      <p className="text-sm text-gray-900">{normalizedData.investigationalDrug}</p>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-500">Biomarkers</label>
                      <p className="text-sm text-gray-900">{normalizedData.biomarkers}</p>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-500">Prevalence</label>
                      <p className="text-sm text-gray-900">{normalizedData.prevalence}</p>
                    </div>
                  </div>
                  <div className="pt-4 border-t border-gray-200">
                    <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 text-sm">
                      Save to Database
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">Suggested preview...</p>
                    <p className="text-sm text-gray-400 mt-2">
                      Enter data in the left panel to see normalized results here
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SurveyIntake; 