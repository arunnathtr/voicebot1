import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';
import { 
  Plus, 
  Search, 
  Filter, 
  Calendar,
  User,
  Building,
  BarChart3
} from 'lucide-react';
import toast from 'react-hot-toast';
import FeasibilityComparison from './FeasibilityComparison';

const Feasibility = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [activeTab, setActiveTab] = useState('studies');
  const [formData, setFormData] = useState({
    studyId: '',
    siteId: '',
    investigator: '',
    disease: '',
    expectedPatients: '',
    startDate: '',
    endDate: '',
    comments: ''
  });
  const queryClient = useQueryClient();

  // Mock feasibility data
  const { data: feasibilityData } = useQuery('feasibility', async () => {
    return {
      studies: [
        {
          id: 1,
          studyId: 'ONC-001',
          siteId: 'SITE-001',
          investigator: 'Dr. Sarah Johnson',
          disease: 'Non-small cell lung cancer',
          expectedPatients: 25,
          actualPatients: 22,
          startDate: '2024-01-15',
          endDate: '2024-06-15',
          status: 'active',
          progress: 88,
          comments: 'Site performing well, minor delays in recruitment'
        },
        {
          id: 2,
          studyId: 'ONC-002',
          siteId: 'SITE-002',
          investigator: 'Dr. Michael Chen',
          disease: 'Breast cancer',
          expectedPatients: 30,
          actualPatients: 18,
          startDate: '2024-02-01',
          endDate: '2024-07-01',
          status: 'active',
          progress: 60,
          comments: 'Recruitment slower than expected, need additional support'
        },
        {
          id: 3,
          studyId: 'ONC-003',
          siteId: 'SITE-003',
          investigator: 'Dr. Emily Rodriguez',
          disease: 'Colorectal cancer',
          expectedPatients: 20,
          actualPatients: 0,
          startDate: '2024-03-01',
          endDate: '2024-08-01',
          status: 'pending',
          progress: 0,
          comments: 'Site approval pending, regulatory review in progress'
        }
      ]
    };
  });

  const createMutation = useMutation(
    async (data) => {
      const response = await axios.post('/api/feasibility', data);
      return response.data;
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries('feasibility');
        toast.success('Feasibility study created successfully');
        setShowForm(false);
        setFormData({
          studyId: '',
          siteId: '',
          investigator: '',
          disease: '',
          expectedPatients: '',
          startDate: '',
          endDate: '',
          comments: ''
        });
      },
      onError: (error) => {
        toast.error(error.response?.data?.error || 'Failed to create study');
      }
    }
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getProgressColor = (progress) => {
    if (progress >= 80) return 'bg-green-500';
    if (progress >= 60) return 'bg-yellow-500';
    if (progress >= 40) return 'bg-orange-500';
    return 'bg-red-500';
  };

  if (!feasibilityData) return <div>Loading feasibility data...</div>;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Feasibility Studies</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage and track feasibility assessments for clinical trials
          </p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>New Study</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('studies')}
              className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                activeTab === 'studies'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Building className="h-4 w-4" />
              <span>Studies</span>
            </button>
            <button
              onClick={() => setActiveTab('comparison')}
              className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                activeTab === 'comparison'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <BarChart3 className="h-4 w-4" />
              <span>Comparison</span>
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'studies' && (
            <>
              {/* Search and Filters */}
              <div className="bg-white p-4 rounded-lg shadow mb-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search studies..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                      />
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Filter className="h-4 w-4 text-gray-400" />
                    <select
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                    >
                      <option value="all">All Status</option>
                      <option value="active">Active</option>
                      <option value="pending">Pending</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Studies Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {feasibilityData.studies
                  .filter(study => 
                    (statusFilter === 'all' || study.status === statusFilter) &&
                    (searchQuery === '' || 
                     study.studyId.toLowerCase().includes(searchQuery.toLowerCase()) ||
                     study.investigator.toLowerCase().includes(searchQuery.toLowerCase()) ||
                     study.disease.toLowerCase().includes(searchQuery.toLowerCase()))
                  )
                  .map((study) => (
                  <div key={study.id} className="bg-white rounded-lg shadow hover:shadow-md transition-shadow">
                    <div className="p-6">
                      {/* Header */}
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{study.studyId}</h3>
                          <p className="text-sm text-gray-500">{study.siteId}</p>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(study.status)}`}>
                          {study.status}
                        </span>
                      </div>

                      {/* Study Details */}
                      <div className="space-y-3 mb-4">
                        <div className="flex items-center space-x-2">
                          <User className="h-4 w-4 text-gray-400" />
                          <span className="text-sm text-gray-600">{study.investigator}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Building className="h-4 w-4 text-gray-400" />
                          <span className="text-sm text-gray-600">{study.disease}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Calendar className="h-4 w-4 text-gray-400" />
                          <span className="text-sm text-gray-600">
                            {new Date(study.startDate).toLocaleDateString()} - {new Date(study.endDate).toLocaleDateString()}
                          </span>
                        </div>
                      </div>

                      {/* Progress */}
                      <div className="mb-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-gray-700">Recruitment Progress</span>
                          <span className="text-sm text-gray-500">{study.progress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${getProgressColor(study.progress)}`}
                            style={{ width: `${study.progress}%` }}
                          ></div>
                        </div>
                        <div className="flex justify-between text-xs text-gray-500 mt-1">
                          <span>Expected: {study.expectedPatients}</span>
                          <span>Actual: {study.actualPatients}</span>
                        </div>
                      </div>

                      {/* Comments */}
                      {study.comments && (
                        <div className="pt-4 border-t border-gray-200">
                          <p className="text-sm text-gray-600">{study.comments}</p>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="mt-4 pt-4 border-t border-gray-200 flex justify-end space-x-2">
                        <button className="text-sm text-indigo-600 hover:text-indigo-800">
                          View Details
                        </button>
                        <button className="text-sm text-gray-600 hover:text-gray-800">
                          Edit
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {activeTab === 'comparison' && (
            <FeasibilityComparison />
          )}
        </div>
      </div>

      {/* New Study Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">New Feasibility Study</h3>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Study ID</label>
                    <input
                      type="text"
                      name="studyId"
                      value={formData.studyId}
                      onChange={handleChange}
                      required
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Site ID</label>
                    <input
                      type="text"
                      name="siteId"
                      value={formData.siteId}
                      onChange={handleChange}
                      required
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Investigator</label>
                  <input
                    type="text"
                    name="investigator"
                    value={formData.investigator}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Disease</label>
                  <input
                    type="text"
                    name="disease"
                    value={formData.disease}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Expected Patients</label>
                  <input
                    type="number"
                    name="expectedPatients"
                    value={formData.expectedPatients}
                    onChange={handleChange}
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Start Date</label>
                    <input
                      type="date"
                      name="startDate"
                      value={formData.startDate}
                      onChange={handleChange}
                      required
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">End Date</label>
                    <input
                      type="date"
                      name="endDate"
                      value={formData.endDate}
                      onChange={handleChange}
                      required
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Comments</label>
                  <textarea
                    name="comments"
                    value={formData.comments}
                    onChange={handleChange}
                    rows={3}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={createMutation.isLoading}
                    className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 disabled:opacity-50"
                  >
                    {createMutation.isLoading ? 'Creating...' : 'Create Study'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Feasibility; 