import React from 'react';
import { useQuery } from 'react-query';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from 'recharts';
import { 
  TrendingUp, 
  CheckCircle,
  Target,
  Users,
  Clock
} from 'lucide-react';

const FeasibilityComparison = () => {


  // Mock feasibility comparison data based on the image
  const { data: comparisonData } = useQuery('feasibility-comparison', async () => {
    return {
      studyInfo: {
        title: "Feasibility stage vs exact clinical trial",
        feasibilitySites: 9,
        selectedSites: 8,
        studyName: "ONC-001"
      },
      feasibilityStage: [
        {
          id: 'A',
          hospital: 'Raja Permaisuri Bainun Hospital, Ipoh',
          cda: 'Yes',
          dateQSent: '05/04/2023',
          dateQReceived: '05/04/2023',
          rejected: 'Yes',
          participation: 'Yes',
          rejectReason: 'Not Required',
          feasibilityAnswered: 'Yes',
          projectedRecruit: '3-5'
        },
        {
          id: 'B',
          hospital: 'Beacon Hospital',
          cda: 'Yes',
          dateQSent: '10/04/2023',
          dateQReceived: '15/04/2023',
          rejected: 'Yes',
          participation: 'Yes',
          rejectReason: 'Not Required',
          feasibilityAnswered: 'Yes',
          projectedRecruit: '2-2'
        },
        {
          id: 'C',
          hospital: 'Pulau Pinang Hospital',
          cda: 'Yes',
          dateQSent: '12/04/2023',
          dateQReceived: '18/04/2023',
          rejected: 'Yes',
          participation: 'Yes',
          rejectReason: 'Not Required',
          feasibilityAnswered: 'Yes',
          projectedRecruit: '4-4'
        },
        {
          id: 'D',
          hospital: 'International Islamic University Malaysia (IIUM) - Kuantan Campus',
          cda: 'Yes',
          dateQSent: '08/04/2023',
          dateQReceived: '20/04/2023',
          rejected: 'Yes',
          participation: 'Yes',
          rejectReason: 'Not Required',
          feasibilityAnswered: 'Yes',
          projectedRecruit: '1-2'
        },
        {
          id: 'E',
          hospital: 'Columbia Asia Hospital - Bukit Rimau',
          cda: 'Yes',
          dateQSent: '15/04/2023',
          dateQReceived: '22/04/2023',
          rejected: 'Yes',
          participation: 'Yes',
          rejectReason: 'Not Required',
          feasibilityAnswered: 'Yes',
          projectedRecruit: '0-1'
        },
        {
          id: 'F',
          hospital: 'National Cancer Institute (IKN)',
          cda: 'Yes',
          dateQSent: '20/04/2023',
          dateQReceived: '25/04/2023',
          rejected: 'Yes',
          participation: 'Yes',
          rejectReason: 'Not Required',
          feasibilityAnswered: 'Yes',
          projectedRecruit: '2-3'
        },
        {
          id: 'G',
          hospital: 'Pantai Hospital Sungai Petani',
          cda: 'Yes',
          dateQSent: '25/04/2023',
          dateQReceived: '30/04/2023',
          rejected: 'Yes',
          participation: 'Yes',
          rejectReason: 'Not Required',
          feasibilityAnswered: 'Yes',
          projectedRecruit: '1-1'
        },
        {
          id: 'H',
          hospital: 'Universiti Sains Malaysia (USM), Health Campus',
          cda: 'Yes',
          dateQSent: '30/04/2023',
          dateQReceived: '05/05/2023',
          rejected: 'Yes',
          participation: 'Yes',
          rejectReason: 'Not Required',
          feasibilityAnswered: 'Yes',
          projectedRecruit: '1-2'
        },
        {
          id: 'I',
          hospital: 'Sarawak General Hospital',
          cda: 'Yes',
          dateQSent: '14/05/2023',
          dateQReceived: '25/05/2023',
          rejected: 'Yes',
          participation: 'Yes',
          rejectReason: 'Not Required',
          feasibilityAnswered: 'Yes',
          projectedRecruit: '1-2'
        }
      ],
      recruitmentStatus: [
        {
          id: 'A',
          hospital: 'Raja Permaisuri Bainun Hospital, Ipoh',
          trialSiteStatus: 'View Recruiting',
          principalInvestigator: '',
          mainSC: '',
          actualSIVDate: '23/01/2024',
          siteActivationDate: '30/01/2024',
          recruitmentTarget: 3,
          recruitmentAchieved: 2
        },
        {
          id: 'B',
          hospital: 'Pulau Pinang Hospital',
          trialSiteStatus: 'View Recruiting',
          principalInvestigator: '',
          mainSC: '',
          actualSIVDate: '01/02/2024',
          siteActivationDate: '02/02/2024',
          recruitmentTarget: 3,
          recruitmentAchieved: 1
        },
        {
          id: 'C',
          hospital: 'National Cancer Institute (IKN)',
          trialSiteStatus: 'View Recruiting',
          principalInvestigator: '',
          mainSC: '',
          actualSIVDate: '06/02/2024',
          siteActivationDate: '09/02/2024',
          recruitmentTarget: 2,
          recruitmentAchieved: 4
        },
        {
          id: 'D',
          hospital: 'Sarawak General Hospital',
          trialSiteStatus: 'View Recruiting',
          principalInvestigator: '',
          mainSC: '',
          actualSIVDate: '09/01/2024',
          siteActivationDate: '25/01/2024',
          recruitmentTarget: 3,
          recruitmentAchieved: 2
        },
        {
          id: 'E',
          hospital: 'Pantai Hospital Sungai Petani',
          trialSiteStatus: 'View Recruiting',
          principalInvestigator: '',
          mainSC: '',
          actualSIVDate: '26/05/2024',
          siteActivationDate: '03/06/2024',
          recruitmentTarget: 3,
          recruitmentAchieved: 0
        },
        {
          id: 'F',
          hospital: 'Beacon Hospital',
          trialSiteStatus: 'View Recruiting',
          principalInvestigator: '',
          mainSC: '',
          actualSIVDate: '',
          siteActivationDate: '',
          recruitmentTarget: 0,
          recruitmentAchieved: 0
        },
        {
          id: 'H',
          hospital: 'University Malaya Medical Centre (UMMC)',
          trialSiteStatus: 'View Not Yet Recruiting',
          principalInvestigator: '',
          mainSC: '',
          actualSIVDate: '',
          siteActivationDate: '',
          recruitmentTarget: 0,
          recruitmentAchieved: 0
        },
        {
          id: 'I',
          hospital: 'Universiti Sains Malaysia (USM), Health Campus',
          trialSiteStatus: 'View Not Yet Recruiting',
          principalInvestigator: '',
          mainSC: '',
          actualSIVDate: '',
          siteActivationDate: '',
          recruitmentTarget: 0,
          recruitmentAchieved: 0
        }
      ]
    };
  });

  if (!comparisonData) return <div>Loading comparison data...</div>;

  // Calculate summary statistics
  const summary = {
    totalFeasibilitySites: comparisonData.feasibilityStage.length,
    totalSelectedSites: comparisonData.recruitmentStatus.length,
    totalProjectedRecruitment: comparisonData.feasibilityStage.reduce((acc, site) => {
      const [, max] = site.projectedRecruit.split('-').map(Number);
      return acc + max;
    }, 0),
    totalActualRecruitment: comparisonData.recruitmentStatus.reduce((acc, site) => acc + site.recruitmentAchieved, 0),
    totalTargetRecruitment: comparisonData.recruitmentStatus.reduce((acc, site) => acc + site.recruitmentTarget, 0),
    activeSites: comparisonData.recruitmentStatus.filter(site => site.trialSiteStatus === 'View Recruiting').length,
    inactiveSites: comparisonData.recruitmentStatus.filter(site => site.trialSiteStatus === 'View Not Yet Recruiting').length
  };

  // Prepare chart data
  const chartData = comparisonData.recruitmentStatus.map(site => ({
    site: site.hospital.split(' ')[0], // First word of hospital name
    projected: comparisonData.feasibilityStage.find(f => f.id === site.id)?.projectedRecruit?.split('-')[1] || 0,
    target: site.recruitmentTarget,
    achieved: site.recruitmentAchieved
  }));

  const getStatusColor = (status) => {
    switch (status) {
      case 'View Recruiting': return 'bg-green-100 text-green-800';
      case 'View Not Yet Recruiting': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getProgressColor = (achieved, target) => {
    if (target === 0) return 'bg-gray-300';
    const percentage = (achieved / target) * 100;
    if (percentage >= 80) return 'bg-green-500';
    if (percentage >= 60) return 'bg-yellow-500';
    if (percentage >= 40) return 'bg-orange-500';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Feasibility Comparison</h1>
        <p className="mt-1 text-sm text-gray-500">
          {comparisonData.studyInfo.title} ({comparisonData.studyInfo.feasibilitySites} sites involved in feasibility, {comparisonData.studyInfo.selectedSites} sites are selected)
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-blue-600">Feasibility Sites</p>
              <p className="text-2xl font-bold text-blue-900">{summary.totalFeasibilitySites}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <CheckCircle className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-green-600">Selected Sites</p>
              <p className="text-2xl font-bold text-green-900">{summary.totalSelectedSites}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <Target className="h-8 w-8 text-purple-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-purple-600">Total Target</p>
              <p className="text-2xl font-bold text-purple-900">{summary.totalTargetRecruitment}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <TrendingUp className="h-8 w-8 text-orange-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-orange-600">Total Achieved</p>
              <p className="text-2xl font-bold text-orange-900">{summary.totalActualRecruitment}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Recruitment Comparison</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="site" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="projected" fill="#3B82F6" name="Projected (Feasibility)" />
              <Bar dataKey="target" fill="#10B981" name="Target (Trial)" />
              <Bar dataKey="achieved" fill="#F59E0B" name="Achieved" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Site Status Distribution</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="ml-2 text-sm font-medium text-green-800">Active Sites</span>
              </div>
              <span className="text-lg font-bold text-green-900">{summary.activeSites}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-yellow-600" />
                <span className="ml-2 text-sm font-medium text-yellow-800">Inactive Sites</span>
              </div>
              <span className="text-lg font-bold text-yellow-900">{summary.inactiveSites}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center">
                <Target className="h-5 w-5 text-blue-600" />
                <span className="ml-2 text-sm font-medium text-blue-800">Recruitment Rate</span>
              </div>
              <span className="text-lg font-bold text-blue-900">
                {summary.totalTargetRecruitment > 0 
                  ? Math.round((summary.totalActualRecruitment / summary.totalTargetRecruitment) * 100)
                  : 0}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Feasibility Stage Table */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Feasibility Stage Data</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Site</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hospital</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CDA</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Q Sent</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Q Received</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Participation</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Projected</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {comparisonData.feasibilityStage.map((site) => (
                <tr key={site.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{site.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{site.hospital}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{site.cda}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{site.dateQSent}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{site.dateQReceived}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      {site.participation}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{site.projectedRecruit}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recruitment Status Table */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Recruitment Status</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Site</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hospital</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SIV Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Activation</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Target</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Achieved</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Progress</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {comparisonData.recruitmentStatus.map((site) => (
                <tr key={site.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{site.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{site.hospital}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(site.trialSiteStatus)}`}>
                      {site.trialSiteStatus}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{site.actualSIVDate || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{site.siteActivationDate || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{site.recruitmentTarget}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{site.recruitmentAchieved}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                        <div
                          className={`h-2 rounded-full ${getProgressColor(site.recruitmentAchieved, site.recruitmentTarget)}`}
                          style={{ 
                            width: `${site.recruitmentTarget > 0 ? (site.recruitmentAchieved / site.recruitmentTarget) * 100 : 0}%` 
                          }}
                        ></div>
                      </div>
                      <span className="text-xs text-gray-500">
                        {site.recruitmentTarget > 0 
                          ? Math.round((site.recruitmentAchieved / site.recruitmentTarget) * 100)
                          : 0}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FeasibilityComparison; 