import React, { useState } from 'react';
import { useQuery } from 'react-query';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from 'recharts';
import { 
  TrendingUp, 
  Users, 
  Calendar, 
  MapPin,
  AlertCircle
} from 'lucide-react';

const Analytics = () => {
  const [timeRange, setTimeRange] = useState('6months');
  const [selectedMetric, setSelectedMetric] = useState('recruitment');

  // Mock analytics data
  const { data: analyticsData } = useQuery('analytics', async () => {
    return {
      recruitmentTrends: [
        { month: 'Jan', projected: 45, actual: 42, sites: 8 },
        { month: 'Feb', projected: 52, actual: 48, sites: 10 },
        { month: 'Mar', projected: 58, actual: 55, sites: 12 },
        { month: 'Apr', projected: 65, actual: 62, sites: 15 },
        { month: 'May', projected: 72, actual: 68, sites: 18 },
        { month: 'Jun', projected: 78, actual: 75, sites: 20 }
      ],
      sitePerformance: [
        { name: 'Site A', patients: 25, success: 85, efficiency: 92 },
        { name: 'Site B', patients: 18, success: 72, efficiency: 78 },
        { name: 'Site C', patients: 32, success: 91, efficiency: 95 },
        { name: 'Site D', patients: 15, success: 67, efficiency: 71 },
        { name: 'Site E', patients: 28, success: 89, efficiency: 88 }
      ],
      diseaseDistribution: [
        { name: 'Lung Cancer', value: 35, color: '#3B82F6' },
        { name: 'Breast Cancer', value: 28, color: '#10B981' },
        { name: 'Colorectal Cancer', value: 22, color: '#F59E0B' },
        { name: 'Prostate Cancer', value: 15, color: '#EF4444' }
      ],
      geographicData: [
        { region: 'North America', studies: 45, patients: 1200 },
        { region: 'Europe', studies: 38, patients: 980 },
        { region: 'Asia Pacific', studies: 32, patients: 850 },
        { region: 'Latin America', studies: 25, patients: 650 },
        { region: 'Africa', studies: 15, patients: 320 }
      ]
    };
  });

  const MetricCard = ({ title, value, change, icon: Icon, color }) => (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex items-center">
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
        <div className="ml-4">
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <p className="text-2xl font-semibold text-gray-900">{value}</p>
          {change && (
            <p className={`text-sm ${change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
              {change} from last month
            </p>
          )}
        </div>
      </div>
    </div>
  );

  if (!analyticsData) return <div>Loading analytics...</div>;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
          <p className="mt-1 text-sm text-gray-500">
            Comprehensive insights into feasibility performance
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
          >
            <option value="3months">Last 3 Months</option>
            <option value="6months">Last 6 Months</option>
            <option value="12months">Last 12 Months</option>
          </select>
          <select
            value={selectedMetric}
            onChange={(e) => setSelectedMetric(e.target.value)}
            className="border border-gray-300 rounded-md px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
          >
            <option value="recruitment">Recruitment</option>
            <option value="sites">Site Performance</option>
            <option value="diseases">Disease Distribution</option>
            <option value="geographic">Geographic Analysis</option>
          </select>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Studies"
          value="156"
          change="+12%"
          icon={TrendingUp}
          color="bg-blue-500"
        />
        <MetricCard
          title="Active Sites"
          value="89"
          change="+8%"
          icon={Users}
          color="bg-green-500"
        />
        <MetricCard
          title="Total Patients"
          value="4,250"
          change="+15%"
          icon={Calendar}
          color="bg-purple-500"
        />
        <MetricCard
          title="Success Rate"
          value="87%"
          change="+3%"
          icon={MapPin}
          color="bg-orange-500"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recruitment Trends */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Recruitment Trends</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={analyticsData.recruitmentTrends}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Area type="monotone" dataKey="projected" stackId="1" stroke="#3B82F6" fill="#3B82F6" fillOpacity={0.3} />
              <Area type="monotone" dataKey="actual" stackId="1" stroke="#10B981" fill="#10B981" fillOpacity={0.3} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Disease Distribution */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Disease Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={analyticsData.diseaseDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {analyticsData.diseaseDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Site Performance */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Site Performance Comparison</h3>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={analyticsData.sitePerformance}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="patients" fill="#3B82F6" name="Patients" />
            <Bar dataKey="success" fill="#10B981" name="Success Rate (%)" />
            <Bar dataKey="efficiency" fill="#F59E0B" name="Efficiency (%)" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Geographic Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Geographic Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={analyticsData.geographicData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="region" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="studies" fill="#3B82F6" name="Studies" />
              <Bar dataKey="patients" fill="#10B981" name="Patients" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Performance Insights</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-green-800">Top Performing Site</p>
                <p className="text-xs text-green-600">Site C - 91% success rate</p>
              </div>
              <TrendingUp className="h-5 w-5 text-green-600" />
            </div>
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-yellow-800">Needs Attention</p>
                <p className="text-xs text-yellow-600">Site D - 67% success rate</p>
              </div>
              <AlertCircle className="h-5 w-5 text-yellow-600" />
            </div>
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-blue-800">Most Active Region</p>
                <p className="text-xs text-blue-600">North America - 45 studies</p>
              </div>
              <MapPin className="h-5 w-5 text-blue-600" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics; 