import React from 'react';
import { useQuery } from 'react-query';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  FileText, 
  Users, 
  TrendingUp, 
  Clock,
  ClipboardCheck,
  Activity,
  TestTube,
  Pill,
  Target
} from 'lucide-react';

const Dashboard = () => {
  // Mock data - replace with actual API calls
  const { data: stats } = useQuery('dashboard-stats', async () => {
    return {
      totalDocuments: 156,
      totalUsers: 24,
      activeStudies: 8,
      pendingReviews: 12,
      totalSurveys: 45,
      oncologyStudies: 12,
      surveyCompletion: 78,
      oncologyRecruitment: 92,
      recentActivity: [
        { id: 1, type: 'document', message: 'New feasibility survey uploaded', time: '2 hours ago', user: 'Dr. Smith' },
        { id: 2, type: 'user', message: 'Site investigator registered', time: '4 hours ago', user: 'Dr. Johnson' },
        { id: 3, type: 'study', message: 'Study ONC-001 feasibility completed', time: '1 day ago', user: 'Feasibility Team' },
        { id: 4, type: 'analytics', message: 'Analytics report generated', time: '2 days ago', user: 'Analytics Team' },
        { id: 5, type: 'survey', message: 'Oncology survey completed for Site A', time: '3 hours ago', user: 'Dr. Chen' },
        { id: 6, type: 'oncology', message: 'HER2+ patient data updated', time: '5 hours ago', user: 'Dr. Rodriguez' }
      ]
    };
  });

  const recruitmentData = [
    { month: 'Jan', projected: 45, actual: 42 },
    { month: 'Feb', projected: 52, actual: 48 },
    { month: 'Mar', projected: 58, actual: 55 },
    { month: 'Apr', projected: 65, actual: 62 },
    { month: 'May', projected: 72, actual: 68 },
    { month: 'Jun', projected: 78, actual: 75 }
  ];

  const sitePerformance = [
    { name: 'Site A', patients: 25, success: 85 },
    { name: 'Site B', patients: 18, success: 72 },
    { name: 'Site C', patients: 32, success: 91 },
    { name: 'Site D', patients: 15, success: 67 },
    { name: 'Site E', patients: 28, success: 89 }
  ];

  const documentTypes = [
    { name: 'Feasibility Surveys', value: 45, color: '#3B82F6' },
    { name: 'Protocol Documents', value: 25, color: '#10B981' },
    { name: 'Site Reports', value: 20, color: '#F59E0B' },
    { name: 'Analytics Reports', value: 10, color: '#EF4444' }
  ];

  const surveyData = [
    { month: 'Jan', completed: 12, pending: 8 },
    { month: 'Feb', completed: 15, pending: 6 },
    { month: 'Mar', completed: 18, pending: 4 },
    { month: 'Apr', completed: 22, pending: 3 },
    { month: 'May', completed: 25, pending: 2 },
    { month: 'Jun', completed: 28, pending: 1 }
  ];

  const oncologyData = [
    { cancerType: 'Breast Cancer', patients: 45, recruitment: 92 },
    { cancerType: 'Lung Cancer', patients: 32, recruitment: 88 },
    { cancerType: 'Colorectal', patients: 28, recruitment: 85 },
    { cancerType: 'Prostate', patients: 22, recruitment: 90 },
    { cancerType: 'Ovarian', patients: 18, recruitment: 87 }
  ];

  const biomarkerData = [
    { biomarker: 'HER2+', positive: 65, negative: 35 },
    { biomarker: 'PD-L1+', positive: 45, negative: 55 },
    { biomarker: 'BRCA1/2', positive: 25, negative: 75 },
    { biomarker: 'ALK+', positive: 15, negative: 85 }
  ];

  const StatCard = ({ title, value, icon: Icon, change, changeType }) => (
    <div className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <Icon className="h-6 w-6 text-gray-400" />
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">{title}</dt>
              <dd className="flex items-baseline">
                <div className="text-2xl font-semibold text-gray-900">{value}</div>
                {change && (
                  <div className={`ml-2 flex items-baseline text-sm font-semibold ${
                    changeType === 'positive' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {changeType === 'positive' ? '↑' : '↓'} {change}
                  </div>
                )}
              </dd>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );

  const ActivityItem = ({ activity }) => {
    const getIcon = (type) => {
      switch (type) {
        case 'document': return <FileText className="h-4 w-4 text-blue-500" />;
        case 'user': return <Users className="h-4 w-4 text-green-500" />;
        case 'study': return <TrendingUp className="h-4 w-4 text-purple-500" />;
        case 'analytics': return <BarChart className="h-4 w-4 text-orange-500" />;
        case 'survey': return <ClipboardCheck className="h-4 w-4 text-indigo-500" />;
        case 'oncology': return <Activity className="h-4 w-4 text-red-500" />;
        default: return <Clock className="h-4 w-4 text-gray-500" />;
      }
    };

    return (
      <div className="flex items-center space-x-3 py-2">
        <div className="flex-shrink-0">
          {getIcon(activity.type)}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm text-gray-900">{activity.message}</p>
          <p className="text-xs text-gray-500">by {activity.user} • {activity.time}</p>
        </div>
      </div>
    );
  };

  if (!stats) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="mt-1 text-sm text-gray-500">
          Overview of your feasibility analytics system
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Documents"
          value={stats.totalDocuments}
          icon={FileText}
          change="12%"
          changeType="positive"
        />
        <StatCard
          title="Active Users"
          value={stats.totalUsers}
          icon={Users}
          change="8%"
          changeType="positive"
        />
        <StatCard
          title="Active Studies"
          value={stats.activeStudies}
          icon={TrendingUp}
          change="3%"
          changeType="positive"
        />
        <StatCard
          title="Pending Reviews"
          value={stats.pendingReviews}
          icon={Clock}
          change="5%"
          changeType="negative"
        />
      </div>

      {/* Survey & Oncology Stats */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Surveys"
          value={stats.totalSurveys}
          icon={ClipboardCheck}
          change="15%"
          changeType="positive"
        />
        <StatCard
          title="Oncology Studies"
          value={stats.oncologyStudies}
          icon={Activity}
          change="22%"
          changeType="positive"
        />
        <StatCard
          title="Survey Completion"
          value={`${stats.surveyCompletion}%`}
          icon={Target}
          change="8%"
          changeType="positive"
        />
        <StatCard
          title="Oncology Recruitment"
          value={`${stats.oncologyRecruitment}%`}
          icon={TestTube}
          change="12%"
          changeType="positive"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recruitment Trends */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Recruitment Trends</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={recruitmentData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="projected" stroke="#3B82F6" strokeWidth={2} name="Projected" />
              <Line type="monotone" dataKey="actual" stroke="#10B981" strokeWidth={2} name="Actual" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Survey Completion Trends */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Survey Completion Trends</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={surveyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="completed" stroke="#3B82F6" strokeWidth={2} name="Completed" />
              <Line type="monotone" dataKey="pending" stroke="#F59E0B" strokeWidth={2} name="Pending" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Oncology & Survey Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Oncology Studies by Cancer Type */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Oncology Studies by Cancer Type</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={oncologyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="cancerType" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="patients" fill="#3B82F6" name="Patients" />
              <Bar dataKey="recruitment" fill="#10B981" name="Recruitment %" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Biomarker Distribution */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Biomarker Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={biomarkerData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ biomarker, percent }) => `${biomarker} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="positive"
              >
                {biomarkerData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={['#3B82F6', '#10B981', '#F59E0B', '#EF4444'][index]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Site Performance & Document Types */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Site Performance */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Site Performance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={sitePerformance}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="patients" fill="#3B82F6" name="Patients" />
              <Bar dataKey="success" fill="#10B981" name="Success Rate (%)" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Document Types */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Document Types</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={documentTypes}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {documentTypes.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Activity</h3>
        <div className="space-y-3">
          {stats.recentActivity.map((activity) => (
            <ActivityItem key={activity.id} activity={activity} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard; 