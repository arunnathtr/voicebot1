const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Tesseract = require('tesseract.js');
const pdfParse = require('pdf-parse');
const mammoth = require('mammoth');
const XLSX = require('xlsx');
const router = express.Router();

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  const jwt = require('jsonwebtoken');
  jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 50 * 1024 * 1024 // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'image/jpeg',
      'image/png',
      'image/tiff'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'), false);
    }
  }
});

// Mock documents database
let documents = [
  {
    id: 1,
    filename: 'feasibility-survey-2024.pdf',
    originalName: 'feasibility-survey-2024.pdf',
    fileType: 'application/pdf',
    fileSize: 2048576,
    uploadedBy: 'feasibility@feasibility.com',
    uploadedAt: new Date(),
    status: 'processed',
    tags: ['feasibility', 'survey', 'oncology'],
    extractedText: 'Sample extracted text from feasibility survey...',
    metadata: {
      studyId: 'ONC-001',
      siteId: 'SITE-001',
      investigator: 'Dr. Smith'
    }
  }
];

// Upload document with OCR processing
router.post('/upload', authenticateToken, upload.single('document'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const file = req.file;
    const { tags, studyId, siteId, investigator } = req.body;

    // Process file based on type
    let extractedText = '';
    let metadata = {};

    if (file.mimetype === 'application/pdf') {
      const dataBuffer = fs.readFileSync(file.path);
      const pdfData = await pdfParse(dataBuffer);
      extractedText = pdfData.text;
    } else if (file.mimetype.includes('word')) {
      const result = await mammoth.extractRawText({ path: file.path });
      extractedText = result.value;
    } else if (file.mimetype.includes('excel')) {
      const workbook = XLSX.readFile(file.path);
      const sheetNames = workbook.SheetNames;
      extractedText = sheetNames.map(name => {
        const sheet = workbook.Sheets[name];
        return XLSX.utils.sheet_to_txt(sheet);
      }).join('\n');
    } else if (file.mimetype.startsWith('image/')) {
      // OCR processing for images
      const { data: { text } } = await Tesseract.recognize(file.path, 'eng');
      extractedText = text;
    }

    // Create document record
    const document = {
      id: documents.length + 1,
      filename: file.filename,
      originalName: file.originalname,
      fileType: file.mimetype,
      fileSize: file.size,
      uploadedBy: req.user.email,
      uploadedAt: new Date(),
      status: 'processed',
      tags: tags ? tags.split(',').map(tag => tag.trim()) : [],
      extractedText,
      metadata: {
        studyId,
        siteId,
        investigator,
        uploadedBy: req.user.name,
        organization: req.user.organization
      }
    };

    documents.push(document);

    res.status(201).json({
      message: 'Document uploaded and processed successfully',
      document: {
        id: document.id,
        filename: document.filename,
        originalName: document.originalName,
        fileSize: document.fileSize,
        status: document.status,
        tags: document.tags,
        uploadedAt: document.uploadedAt,
        metadata: document.metadata
      }
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'Error processing document' });
  }
});

// Get all documents
router.get('/', authenticateToken, (req, res) => {
  const { page = 1, limit = 10, status, tags, studyId } = req.query;
  
  let filteredDocs = documents;

  // Apply filters
  if (status) {
    filteredDocs = filteredDocs.filter(doc => doc.status === status);
  }
  
  if (tags) {
    const tagArray = tags.split(',').map(tag => tag.trim());
    filteredDocs = filteredDocs.filter(doc => 
      tagArray.some(tag => doc.tags.includes(tag))
    );
  }
  
  if (studyId) {
    filteredDocs = filteredDocs.filter(doc => 
      doc.metadata.studyId === studyId
    );
  }

  // Pagination
  const startIndex = (page - 1) * limit;
  const endIndex = page * limit;
  const paginatedDocs = filteredDocs.slice(startIndex, endIndex);

  res.json({
    documents: paginatedDocs.map(doc => ({
      id: doc.id,
      filename: doc.filename,
      originalName: doc.originalName,
      fileType: doc.fileType,
      fileSize: doc.fileSize,
      status: doc.status,
      tags: doc.tags,
      uploadedBy: doc.uploadedBy,
      uploadedAt: doc.uploadedAt,
      metadata: doc.metadata
    })),
    pagination: {
      currentPage: parseInt(page),
      totalPages: Math.ceil(filteredDocs.length / limit),
      totalDocuments: filteredDocs.length,
      hasNext: endIndex < filteredDocs.length,
      hasPrev: page > 1
    }
  });
});

// Get document by ID
router.get('/:id', authenticateToken, (req, res) => {
  const document = documents.find(doc => doc.id === parseInt(req.params.id));
  
  if (!document) {
    return res.status(404).json({ error: 'Document not found' });
  }

  res.json({
    document: {
      id: document.id,
      filename: document.filename,
      originalName: document.originalName,
      fileType: document.fileType,
      fileSize: document.fileSize,
      status: document.status,
      tags: document.tags,
      uploadedBy: document.uploadedBy,
      uploadedAt: document.uploadedAt,
      extractedText: document.extractedText,
      metadata: document.metadata
    }
  });
});

// Update document tags
router.patch('/:id/tags', authenticateToken, (req, res) => {
  const { tags } = req.body;
  const document = documents.find(doc => doc.id === parseInt(req.params.id));
  
  if (!document) {
    return res.status(404).json({ error: 'Document not found' });
  }

  document.tags = Array.isArray(tags) ? tags : tags.split(',').map(tag => tag.trim());
  document.updatedAt = new Date();

  res.json({
    message: 'Document tags updated successfully',
    document: {
      id: document.id,
      tags: document.tags,
      updatedAt: document.updatedAt
    }
  });
});

// Delete document
router.delete('/:id', authenticateToken, (req, res) => {
  const documentIndex = documents.findIndex(doc => doc.id === parseInt(req.params.id));
  
  if (documentIndex === -1) {
    return res.status(404).json({ error: 'Document not found' });
  }

  const document = documents[documentIndex];
  
  // Delete file from filesystem
  const filePath = path.join(__dirname, 'uploads', document.filename);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }

  // Remove from database
  documents.splice(documentIndex, 1);

  res.json({ message: 'Document deleted successfully' });
});

// Search documents by text content
router.get('/search/text', authenticateToken, (req, res) => {
  const { query } = req.query;
  
  if (!query) {
    return res.status(400).json({ error: 'Search query required' });
  }

  const searchResults = documents.filter(doc => 
    doc.extractedText.toLowerCase().includes(query.toLowerCase()) ||
    doc.originalName.toLowerCase().includes(query.toLowerCase()) ||
    doc.tags.some(tag => tag.toLowerCase().includes(query.toLowerCase()))
  );

  res.json({
    results: searchResults.map(doc => ({
      id: doc.id,
      filename: doc.filename,
      originalName: doc.originalName,
      fileType: doc.fileType,
      status: doc.status,
      tags: doc.tags,
      uploadedAt: doc.uploadedAt,
      metadata: doc.metadata
    })),
    totalResults: searchResults.length
  });
});

module.exports = router; 