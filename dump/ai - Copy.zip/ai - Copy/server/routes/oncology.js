const express = require('express');
const router = express.Router();

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  const jwt = require('jsonwebtoken');
  jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Mock oncology feasibility data
let oncologyStudies = [
  {
    id: 1,
    studyId: 'ONC-001',
    disease: 'Non-small cell lung cancer',
    country: 'United States',
    sites: [
      {
        id: 'SITE-001',
        name: 'Memorial Sloan Kettering Cancer Center',
        investigator: 'Dr. Sarah Johnson',
        status: 'active',
        recruitmentProjection: 25,
        actualRecruitment: 22,
        standardOfCare: 'Platinum-based chemotherapy',
        investigationalDrugs: [
          {
            name: 'Pembrolizumab',
            mechanismOfAction: 'PD-1 inhibitor',
            reimbursement: 'Covered by insurance',
            status: 'approved'
          }
        ],
        biomarkers: ['PD-L1', 'EGFR', 'ALK'],
        labAssessments: {
          routine: ['CBC', 'Chemistry Panel'],
          notRoutine: ['PD-L1 testing', 'NGS panel'],
          local: ['CBC', 'Chemistry'],
          outsource: ['PD-L1', 'NGS']
        },
        prevalence: {
          general: '13% of all cancers',
          treatment: '85% of lung cancer cases',
          mutation: 'EGFR: 15%, ALK: 5%, PD-L1+: 60%'
        }
      }
    ],
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 2,
    studyId: 'ONC-002',
    disease: 'Breast cancer',
    country: 'United Kingdom',
    sites: [
      {
        id: 'SITE-002',
        name: 'Royal Marsden Hospital',
        investigator: 'Dr. Michael Chen',
        status: 'active',
        recruitmentProjection: 30,
        actualRecruitment: 18,
        standardOfCare: 'Anthracycline-based chemotherapy',
        investigationalDrugs: [
          {
            name: 'Trastuzumab',
            mechanismOfAction: 'HER2 inhibitor',
            reimbursement: 'NHS covered',
            status: 'approved'
          }
        ],
        biomarkers: ['HER2', 'ER/PR', 'BRCA1/2'],
        labAssessments: {
          routine: ['CBC', 'Chemistry Panel'],
          notRoutine: ['HER2 testing', 'BRCA testing'],
          local: ['CBC', 'Chemistry'],
          outsource: ['HER2', 'BRCA']
        },
        prevalence: {
          general: '30% of all cancers in women',
          treatment: '90% of breast cancer cases',
          mutation: 'HER2+: 20%, ER+: 70%, BRCA: 5%'
        }
      }
    ],
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

// Get all oncology studies
router.get('/', authenticateToken, (req, res) => {
  const { disease, country, status } = req.query;
  
  let filteredStudies = oncologyStudies;
  
  if (disease) {
    filteredStudies = filteredStudies.filter(study => 
      study.disease.toLowerCase().includes(disease.toLowerCase())
    );
  }
  
  if (country) {
    filteredStudies = filteredStudies.filter(study => 
      study.country.toLowerCase().includes(country.toLowerCase())
    );
  }
  
  if (status) {
    filteredStudies = filteredStudies.filter(study => 
      study.sites.some(site => site.status === status)
    );
  }
  
  res.json({ studies: filteredStudies });
});

// Get oncology study by ID
router.get('/:id', authenticateToken, (req, res) => {
  const study = oncologyStudies.find(s => s.id === parseInt(req.params.id));
  
  if (!study) {
    return res.status(404).json({ error: 'Study not found' });
  }
  
  res.json({ study });
});

// Create new oncology study
router.post('/', authenticateToken, (req, res) => {
  const {
    studyId,
    disease,
    country,
    sites
  } = req.body;
  
  const newStudy = {
    id: oncologyStudies.length + 1,
    studyId,
    disease,
    country,
    sites: sites || [],
    createdAt: new Date(),
    updatedAt: new Date()
  };
  
  oncologyStudies.push(newStudy);
  
  res.status(201).json({
    message: 'Oncology study created successfully',
    study: newStudy
  });
});

// Update oncology study
router.put('/:id', authenticateToken, (req, res) => {
  const studyIndex = oncologyStudies.findIndex(s => s.id === parseInt(req.params.id));
  
  if (studyIndex === -1) {
    return res.status(404).json({ error: 'Study not found' });
  }
  
  const updatedStudy = {
    ...oncologyStudies[studyIndex],
    ...req.body,
    updatedAt: new Date()
  };
  
  oncologyStudies[studyIndex] = updatedStudy;
  
  res.json({
    message: 'Study updated successfully',
    study: updatedStudy
  });
});

// Add site to oncology study
router.post('/:id/sites', authenticateToken, (req, res) => {
  const study = oncologyStudies.find(s => s.id === parseInt(req.params.id));
  
  if (!study) {
    return res.status(404).json({ error: 'Study not found' });
  }
  
  const newSite = {
    id: `SITE-${Date.now()}`,
    ...req.body,
    status: 'pending'
  };
  
  study.sites.push(newSite);
  study.updatedAt = new Date();
  
  res.status(201).json({
    message: 'Site added successfully',
    site: newSite
  });
});

// Update site information
router.put('/:studyId/sites/:siteId', authenticateToken, (req, res) => {
  const study = oncologyStudies.find(s => s.id === parseInt(req.params.studyId));
  
  if (!study) {
    return res.status(404).json({ error: 'Study not found' });
  }
  
  const site = study.sites.find(s => s.id === req.params.siteId);
  
  if (!site) {
    return res.status(404).json({ error: 'Site not found' });
  }
  
  Object.assign(site, req.body);
  study.updatedAt = new Date();
  
  res.json({
    message: 'Site updated successfully',
    site
  });
});

// Get oncology analytics
router.get('/analytics/summary', authenticateToken, (req, res) => {
  const summary = {
    totalStudies: oncologyStudies.length,
    totalSites: oncologyStudies.reduce((acc, study) => acc + study.sites.length, 0),
    diseases: [...new Set(oncologyStudies.map(s => s.disease))],
    countries: [...new Set(oncologyStudies.map(s => s.country))],
    recruitmentStats: {
      projected: oncologyStudies.reduce((acc, study) => 
        acc + study.sites.reduce((siteAcc, site) => siteAcc + site.recruitmentProjection, 0), 0
      ),
      actual: oncologyStudies.reduce((acc, study) => 
        acc + study.sites.reduce((siteAcc, site) => siteAcc + site.actualRecruitment, 0), 0
      )
    },
    biomarkers: [...new Set(oncologyStudies.flatMap(s => 
      s.sites.flatMap(site => site.biomarkers)
    ))],
    drugs: [...new Set(oncologyStudies.flatMap(s => 
      s.sites.flatMap(site => site.investigationalDrugs.map(d => d.name))
    ))]
  };
  
  res.json(summary);
});

// Get standard of care data
router.get('/standard-of-care', authenticateToken, (req, res) => {
  const { disease } = req.query;
  
  const socData = oncologyStudies
    .filter(study => !disease || disease === '' || study.disease.toLowerCase().includes(disease.toLowerCase()))
    .map(study => ({
      studyId: study.studyId,
      disease: study.disease,
      sites: study.sites.map(site => ({
        siteId: site.id,
        siteName: site.name,
        standardOfCare: site.standardOfCare,
        investigationalDrugs: site.investigationalDrugs,
        reimbursement: site.investigationalDrugs.map(d => d.reimbursement)
      }))
    }));
  
  res.json({ standardOfCare: socData });
});

// Get biomarker data
router.get('/biomarkers', authenticateToken, (req, res) => {
  const { disease } = req.query;
  
  const biomarkerData = oncologyStudies
    .filter(study => !disease || disease === '' || study.disease.toLowerCase().includes(disease.toLowerCase()))
    .map(study => ({
      studyId: study.studyId,
      disease: study.disease,
      sites: study.sites.map(site => ({
        siteId: site.id,
        siteName: site.name,
        biomarkers: site.biomarkers,
        labAssessments: site.labAssessments
      }))
    }));
  
  res.json({ biomarkers: biomarkerData });
});

// Get prevalence data
router.get('/prevalence', authenticateToken, (req, res) => {
  const { disease } = req.query;
  
  const prevalenceData = oncologyStudies
    .filter(study => !disease || disease === '' || study.disease.toLowerCase().includes(disease.toLowerCase()))
    .map(study => ({
      studyId: study.studyId,
      disease: study.disease,
      sites: study.sites.map(site => ({
        siteId: site.id,
        siteName: site.name,
        prevalence: site.prevalence
      }))
    }));
  
  res.json({ prevalence: prevalenceData });
});

module.exports = router; 