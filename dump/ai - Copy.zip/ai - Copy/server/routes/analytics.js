const express = require('express');
const router = express.Router();

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  const jwt = require('jsonwebtoken');
  jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Get dashboard statistics
router.get('/dashboard', authenticateToken, (req, res) => {
  const stats = {
    totalDocuments: 156,
    totalUsers: 24,
    activeStudies: 8,
    pendingReviews: 12,
    recentActivity: [
      { id: 1, type: 'document', message: 'New feasibility survey uploaded', time: '2 hours ago', user: 'Dr. Smith' },
      { id: 2, type: 'user', message: 'Site investigator registered', time: '4 hours ago', user: 'Dr. Johnson' },
      { id: 3, type: 'study', message: 'Study ONC-001 feasibility completed', time: '1 day ago', user: 'Feasibility Team' },
      { id: 4, type: 'analytics', message: 'Analytics report generated', time: '2 days ago', user: 'Analytics Team' }
    ]
  };
  
  res.json(stats);
});

// Get recruitment trends
router.get('/recruitment-trends', authenticateToken, (req, res) => {
  const trends = [
    { month: 'Jan', projected: 45, actual: 42, sites: 8 },
    { month: 'Feb', projected: 52, actual: 48, sites: 10 },
    { month: 'Mar', projected: 58, actual: 55, sites: 12 },
    { month: 'Apr', projected: 65, actual: 62, sites: 15 },
    { month: 'May', projected: 72, actual: 68, sites: 18 },
    { month: 'Jun', projected: 78, actual: 75, sites: 20 }
  ];
  
  res.json({ trends });
});

// Get site performance
router.get('/site-performance', authenticateToken, (req, res) => {
  const performance = [
    { name: 'Site A', patients: 25, success: 85, efficiency: 92 },
    { name: 'Site B', patients: 18, success: 72, efficiency: 78 },
    { name: 'Site C', patients: 32, success: 91, efficiency: 95 },
    { name: 'Site D', patients: 15, success: 67, efficiency: 71 },
    { name: 'Site E', patients: 28, success: 89, efficiency: 88 }
  ];
  
  res.json({ performance });
});

// Get disease distribution
router.get('/disease-distribution', authenticateToken, (req, res) => {
  const distribution = [
    { name: 'Lung Cancer', value: 35, color: '#3B82F6' },
    { name: 'Breast Cancer', value: 28, color: '#10B981' },
    { name: 'Colorectal Cancer', value: 22, color: '#F59E0B' },
    { name: 'Prostate Cancer', value: 15, color: '#EF4444' }
  ];
  
  res.json({ distribution });
});

// Get geographic data
router.get('/geographic', authenticateToken, (req, res) => {
  const geographic = [
    { region: 'North America', studies: 45, patients: 1200 },
    { region: 'Europe', studies: 38, patients: 980 },
    { region: 'Asia Pacific', studies: 32, patients: 850 },
    { region: 'Latin America', studies: 25, patients: 650 },
    { region: 'Africa', studies: 15, patients: 320 }
  ];
  
  res.json({ geographic });
});

module.exports = router; 