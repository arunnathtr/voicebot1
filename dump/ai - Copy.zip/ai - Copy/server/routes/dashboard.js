const express = require('express');
const router = express.Router();

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  const jwt = require('jsonwebtoken');
  jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Get dashboard stats
router.get('/stats', authenticateToken, (req, res) => {
  const stats = {
    totalDocuments: 156,
    totalUsers: 24,
    activeStudies: 8,
    pendingReviews: 12,
    recentActivity: [
      { id: 1, type: 'document', message: 'New feasibility survey uploaded', time: '2 hours ago', user: 'Dr. Smith' },
      { id: 2, type: 'user', message: 'Site investigator registered', time: '4 hours ago', user: 'Dr. Johnson' },
      { id: 3, type: 'study', message: 'Study ONC-001 feasibility completed', time: '1 day ago', user: 'Feasibility Team' },
      { id: 4, type: 'analytics', message: 'Analytics report generated', time: '2 days ago', user: 'Analytics Team' }
    ]
  };
  
  res.json(stats);
});

module.exports = router; 