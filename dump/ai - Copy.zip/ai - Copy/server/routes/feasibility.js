const express = require('express');
const router = express.Router();

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  const jwt = require('jsonwebtoken');
  jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Mock feasibility data
let feasibilityStudies = [
  {
    id: 1,
    studyId: 'ONC-001',
    siteId: 'SITE-001',
    investigator: 'Dr. Sarah Johnson',
    disease: 'Non-small cell lung cancer',
    expectedPatients: 25,
    actualPatients: 22,
    startDate: '2024-01-15',
    endDate: '2024-06-15',
    status: 'active',
    progress: 88,
    comments: 'Site performing well, minor delays in recruitment',
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

// Get all feasibility studies
router.get('/', authenticateToken, (req, res) => {
  const { status, search } = req.query;
  
  let filteredStudies = feasibilityStudies;
  
  if (status && status !== 'all') {
    filteredStudies = filteredStudies.filter(study => study.status === status);
  }
  
  if (search) {
    filteredStudies = filteredStudies.filter(study => 
      study.studyId.toLowerCase().includes(search.toLowerCase()) ||
      study.investigator.toLowerCase().includes(search.toLowerCase()) ||
      study.disease.toLowerCase().includes(search.toLowerCase())
    );
  }
  
  res.json({ studies: filteredStudies });
});

// Get feasibility study by ID
router.get('/:id', authenticateToken, (req, res) => {
  const study = feasibilityStudies.find(s => s.id === parseInt(req.params.id));
  
  if (!study) {
    return res.status(404).json({ error: 'Study not found' });
  }
  
  res.json({ study });
});

// Create new feasibility study
router.post('/', authenticateToken, (req, res) => {
  const {
    studyId,
    siteId,
    investigator,
    disease,
    expectedPatients,
    startDate,
    endDate,
    comments
  } = req.body;
  
  const newStudy = {
    id: feasibilityStudies.length + 1,
    studyId,
    siteId,
    investigator,
    disease,
    expectedPatients: parseInt(expectedPatients),
    actualPatients: 0,
    startDate,
    endDate,
    status: 'pending',
    progress: 0,
    comments,
    createdAt: new Date(),
    updatedAt: new Date()
  };
  
  feasibilityStudies.push(newStudy);
  
  res.status(201).json({
    message: 'Feasibility study created successfully',
    study: newStudy
  });
});

// Update feasibility study
router.put('/:id', authenticateToken, (req, res) => {
  const studyIndex = feasibilityStudies.findIndex(s => s.id === parseInt(req.params.id));
  
  if (studyIndex === -1) {
    return res.status(404).json({ error: 'Study not found' });
  }
  
  const updatedStudy = {
    ...feasibilityStudies[studyIndex],
    ...req.body,
    updatedAt: new Date()
  };
  
  feasibilityStudies[studyIndex] = updatedStudy;
  
  res.json({
    message: 'Study updated successfully',
    study: updatedStudy
  });
});

// Delete feasibility study
router.delete('/:id', authenticateToken, (req, res) => {
  const studyIndex = feasibilityStudies.findIndex(s => s.id === parseInt(req.params.id));
  
  if (studyIndex === -1) {
    return res.status(404).json({ error: 'Study not found' });
  }
  
  feasibilityStudies.splice(studyIndex, 1);
  
  res.json({ message: 'Study deleted successfully' });
});

// Update study progress
router.patch('/:id/progress', authenticateToken, (req, res) => {
  const { actualPatients } = req.body;
  const study = feasibilityStudies.find(s => s.id === parseInt(req.params.id));
  
  if (!study) {
    return res.status(404).json({ error: 'Study not found' });
  }
  
  study.actualPatients = parseInt(actualPatients);
  study.progress = Math.round((study.actualPatients / study.expectedPatients) * 100);
  study.updatedAt = new Date();
  
  res.json({
    message: 'Progress updated successfully',
    study
  });
});

module.exports = router; 