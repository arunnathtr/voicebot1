const express = require('express');
const router = express.Router();

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  const jwt = require('jsonwebtoken');
  jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Mock users data
const users = [
  {
    id: 1,
    name: 'Admin User',
    email: 'admin@feasibility.com',
    role: 'admin',
    organization: 'Clinical Ops',
    status: 'active',
    createdAt: new Date()
  },
  {
    id: 2,
    name: 'Feasibility Manager',
    email: 'feasibility@feasibility.com',
    role: 'feasibility',
    organization: 'Feasibility Team',
    status: 'active',
    createdAt: new Date()
  },
  {
    id: 3,
    name: 'Site Investigator',
    email: 'site@feasibility.com',
    role: 'site',
    organization: 'Research Site',
    status: 'active',
    createdAt: new Date()
  }
];

// Get all users
router.get('/', authenticateToken, (req, res) => {
  res.json({ users });
});

// Get user profile
router.get('/profile', authenticateToken, (req, res) => {
  const user = users.find(u => u.id === req.user.id);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  res.json({ user });
});

// Update user profile
router.put('/profile', authenticateToken, (req, res) => {
  const userIndex = users.findIndex(u => u.id === req.user.id);
  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  const updatedUser = {
    ...users[userIndex],
    ...req.body,
    updatedAt: new Date()
  };
  
  users[userIndex] = updatedUser;
  
  res.json({
    message: 'Profile updated successfully',
    user: updatedUser
  });
});

module.exports = router; 