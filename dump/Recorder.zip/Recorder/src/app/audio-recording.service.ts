import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { bufferToWave } from './audio-helper';
import { AudioConfig, SpeechConfig, SpeechRecognizer, ResultReason } from 'microsoft-cognitiveservices-speech-sdk';


// Initialize Azure Speech SDK
const audioConfig = AudioConfig.fromDefaultMicrophoneInput();
const speechConfig = SpeechConfig.fromSubscription('16bf492f19134b4f8be18fb091e8da03', 'eastus');
const recognizer = new SpeechRecognizer(speechConfig, audioConfig);

let completeText = '';



@Injectable({
  providedIn: 'root'
})


export class AudioRecordingService {
  private chunks: any[] = [];
  private mediaRecorder: any;
  private audioContext: AudioContext = new AudioContext();
  private audioBlobSubject = new Subject<Blob>();

  audioBlob$ = this.audioBlobSubject.asObservable();

  

  
  async startRecording() {
    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }
    
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.mediaRecorder = new MediaRecorder(stream);
    this.mediaRecorder.ondataavailable = (event: any) => this.chunks.push(event.data);
    this.mediaRecorder.start();

      // Event handlers
    recognizer.recognizing = (s, e) => {
      console.log(`RECOGNIZING: Text=${e.result.text}`);
    };

    recognizer.recognized = (s, e) => {
      if (e.result.reason === ResultReason.RecognizedSpeech) {
          completeText += e.result.text + ' ';
      } else if (e.result.reason === ResultReason.NoMatch) {
          console.log('No speech could be recognized');
      }
    };

    recognizer.startContinuousRecognitionAsync();

  }

  async stopRecording() {
    if (this.mediaRecorder) {
      this.mediaRecorder.onstop = async () => {
        const audioData = await new Blob(this.chunks).arrayBuffer();
        const audioBuffer = await this.audioContext.decodeAudioData(audioData);
        const wavBlob = bufferToWave(audioBuffer, audioBuffer.length);
        this.audioBlobSubject.next(wavBlob);
        this.chunks = [];
      };
  
      this.mediaRecorder.stop();
    }

    recognizer.stopContinuousRecognitionAsync();
    return completeText
    
    
  }

  
  
}