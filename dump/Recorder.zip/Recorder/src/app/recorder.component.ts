import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AudioRecordingService } from './audio-recording.service';
import { RequestSender } from './callapi';
import { catchError } from 'rxjs';


@Component({
  selector: 'app-root',
  templateUrl: './recorder.component.html',
  styleUrls: ['./recorder.component.css']
})
export class RecorderComponent implements OnInit {
  isRecording = false;
  audioURL: string | null = null;
  @ViewChild('audioPlayer') audioPlayer!: ElementRef<HTMLAudioElement>;


  outputText:any = []; 
  response:string = "";
  visible:any = false;
  errorCode:any =false;

  outputJSON:any = [
	  {
          pattemplatefieldid: 16104,
          value: "Plan of Care here...",
          field: "HTF1014917",
          templatemainheadingid: "TMH4184",
          providerid: null,
          providervisitid: null
      },
      {
          pattemplatefieldid: 16103,
          value: "Diagnosis here ...",
          field: "HTF1014915",
          templatemainheadingid: "TMH4184",
          providerid: null,
          providervisitid: null
      },
      {
          pattemplatefieldid: 16102,
          value: "Lab orders",
          field: "HTF1014913",
          templatemainheadingid: "TMH4184",
          providerid: null,
          providervisitid: null
      },
      {
          pattemplatefieldid: 16101,
          value: "Medication here ...",
          field: "HTF1014911",
          templatemainheadingid: "TMH4184",
          providerid: null,
          providervisitid: null
      },
      {
          pattemplatefieldid: 16100,
          value: "History Here ...",
          field: "HTF1014909",
          templatemainheadingid: "TMH4184",
          providerid: null,
          providervisitid: null
      },
      {
          pattemplatefieldid: 16099,
          value: "Chief Complaints Here ...",
          field: "HTF1014906",
          templatemainheadingid: "TMH4184",
          providerid: null,
          providervisitid: null
      }
  ]

  test:any = false;

  constructor(private audioRecordingService: AudioRecordingService, private cd: ChangeDetectorRef, private requestSender: RequestSender) { }

  ngOnInit() {
    this.audioRecordingService.audioBlob$.subscribe(blob => {
      this.audioURL = window.URL.createObjectURL(blob);
      this.audioPlayer.nativeElement.src = this.audioURL;
      this.cd.detectChanges();
    });


  }

  onTestMode(){
    this.test = true;
    
  }
  offTestMode(){
    this.test = false;
    
  }

  startRecording() {
    this.isRecording = true;
    this.audioRecordingService.startRecording();
  }

  stopRecording() {
    this.isRecording = false;
    let conversation = this.audioRecordingService.stopRecording();
    
    this.requestSender.postData(conversation, this.test).subscribe((response) => {
      // Handle the response
      try {
        this.outputText = response['DoctorNote']['consultation_details'];
      }
      catch(e){
        this.outputText="error"
      }
      this.visible = ((this.outputText !== undefined) || (this.outputText.length > 0)) && (this.outputText != "error")
      this.errorCode = (this.outputText == "error")

      
      if (!this.errorCode) {
        for(let obj of this.outputJSON){
          switch (obj.pattemplatefieldid) {
            case 16104:
                obj.value = this.outputText['plan_of_care'];
                break;
            case 16103:
                obj.value = this.outputText['diagnosis'];
                break;
            case 16102:
                obj.value = this.outputText['lab_orders'];
                break;
            case 16101:
                obj.value = this.outputText['medication'];
                break;
            case 16100:
                obj.value = this.outputText['history'];
                break;
            case 16099:
                obj.value = this.outputText['chief_complaints'];
                break;
        }
        }
    }
    
      console.log(this.outputJSON)

    });
  }

}
