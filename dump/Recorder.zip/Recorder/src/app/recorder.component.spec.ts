import { TestBed } from '@angular/core/testing';
import { RecorderComponent } from './recorder.component';

describe('RecorderComponent', () => {
  beforeEach(() => TestBed.configureTestingModule({
    declarations: [RecorderComponent]
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(RecorderComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'AudioRecorder'`, () => {
    const fixture = TestBed.createComponent(RecorderComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('AudioRecorder');
  });

  it('should render title', () => {
    const fixture = TestBed.createComponent(RecorderComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('.content span')?.textContent).toContain('AudioRecorder app is running!');
  });
});
