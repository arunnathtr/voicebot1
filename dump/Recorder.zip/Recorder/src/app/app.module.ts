import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { RecorderComponent } from './recorder.component';

@NgModule({
  declarations: [
    RecorderComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [RecorderComponent]
})
export class AppModule { }
