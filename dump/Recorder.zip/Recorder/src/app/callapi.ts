import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, from, throwError } from 'rxjs';
import { switchMap, catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class RequestSender {

  constructor(private http: HttpClient) { }

  postData(conversationPromise: Promise<string>, test:any): Observable<any> {
    // Define your headers
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    // Convert the Promise to an Observable
    const conversationObservable = from(conversationPromise);

    // Use switchMap to wait for the conversation Promise to resolve before making the HTTP request
    return conversationObservable.pipe(

      
      switchMap(conversation => {
        const conversation1 = "0:03 Hi, how are you Samuel today?\n\n0:06 Not that great, Sir.\n\n0:08 I have developed nasal congestion, you know, cough and sore throat.\n\n0:13 I feel very feverish today.\n\n0:17 So since when you started having these symptoms?\n\n0:20 Since last two days doctor?\n\n0:24 And did it start suddenly or gradually?\n\n0:27 It is gradual onset.\n\n0:29 I know it started.\n\n0:30 I just had some itchy throat.\n\n0:32 I know kind of a thing.\n\n0:33 Now I know when I swallow hospital two, it is very painful for me.\n\n0:41 And there is the I know I've I've also got one sided headache, one sided headache.\n\n0:49 And you've had any allergies, any history of allergies in the past, Sir, I do have medicinal analogy, but I have been treated for that.\n\n1:01 And any other history of diabetes, hypertension.\n\n1:06 Yeah, my parents are diabetic and hypertensive, but I know thankfully I'm not.\n\n1:12 I I'm, you know, I'm a constant smoker.\n\n1:16 I do one pack a day smoking and anyone else in your family has a similar problem.\n\n1:26 No, no, doctor.\n\n1:27 No, no, it's I'm the first one to have this kind of infection fever kind of a thing.\n\n1:34 I'm.\n\n1:34 I'm also fearing that I should not pass this.\n\n1:37 Yeah, I travel extensively.\n\n1:40 So you were in at home or you were traveling somewhere in the last couple of days or last few days.\n\n1:46 Yeah.\n\n1:47 I was in Oman for for the last couple of days, Doctor.\n\n1:51 I've just returned home.\n\n1:55 So it.\n\n1:56 I mean, it seems like a upper respiratory tract infection.\n\n2:00 It could be your sinus.\n\n2:02 Does it hurt if I check and press near your cheek?\n\n2:06 Yes, Sir.\n\n2:07 Does it hurt there?\n\n2:08 Yes.\n\n2:09 There is some pain, Slight pain.\n\n2:11 Yeah.\n\n2:12 Are you able to hear this properly?\n\n2:16 Yeah, it kind of was.\n\n2:18 Masked muffled's working.\n\n2:21 What about smell?\n\n2:22 Are you able to smell things?\n\n2:25 No, Sir.\n\n2:26 Try this.\n\n2:26 No.\n\n2:27 Try this.\n\n2:27 How is this?\n\n2:28 Can you smell this?\n\n2:29 No.\n\n2:29 No.\n\n2:30 Absolutely no.\n\n2:30 Because my nose both nose are you know are blocked.\n\n2:35 What should I do, Sir?\n\n2:36 A sputum.\n\n2:37 Any sputum?\n\n2:40 Sir, I do have clear sputum.\n\n2:42 You know it's not white in color.\n\n2:44 So I I that's that made me to come to the clinic.\n\n2:48 It is turning white.\n\n2:51 And have you taken any medication so far?\n\n2:56 Have you tried anything?\n\n2:57 No, Sir, not yet.\n\n2:58 I tried in nailing steam, but I'm not.\n\n3:01 I'm lazy at it, You know, I have not started anything.\n\n3:06 Right.\n\n3:07 So it sounds like a like upper respiratory tract infection.\n\n3:10 You know, we're going to treat it conservatively, most likely.\n\n3:14 It seems like a viral infection.\n\n3:15 It could be a bacterial.\n\n3:18 So let's just wait and watch.\n\n3:21 We'll give you some medications symptomatic treatment for your fever, which is paracetamol.\n\n3:28 Then I'd also advise you to take do some gargles.\n\n3:30 You can do gargles with list, stream and twice or thrice a day if you can do a steam relation, that's very, very good.\n\n3:39 OK.\n\n3:40 Otherwise you know and then you come back to us in 2-3 days.\n\n3:44 Let's see how it does.\n\n3:45 You can also try some, you know, hot water with ginger and and some cinnamon at home with green tea, so that and avoid drinking cold drinks for the next few days.\n\n3:58 OK, Sir.\n\n3:59 And if the cough increases if the sputum turns green, then we might have to to start you on some antibiotics.\n\n4:06 But we'll just leave that decision on hold for the moment and let's see how your body immunity fights this out.\n\n4:13 And then we can plan the next step.\n\n4:16 So yeah, you could just come to the clinic in the next few days.\n\n4:20 And if you get worse, we'll start you on antibiotics.\n\n4:24 Otherwise, let's try and manage it conservatively since you're already allergic to penicillin.\n\n4:30 So I don't want to give you any antibiotics for now and just symptomatic treatment, take rest, don't get stressed, avoid travel and even contact.\n\n4:41 You know, we could do a quick COVID test just to make sure that you're not COVID Positive.\n\n4:47 The risk I think sounds good.\n\n4:49 Any questions?\n\n4:50 No, Sir.\n\n4:51 I think I'll.\n\n4:52 I'll follow your advice in case if it is getting green or I'm not able to bear the symptoms.\n\n4:58 I'll have a follow up with you, Sir.\n\n5:00 Yeah, sure.\n\n5:02 And once we get the code results, we'll we'll get in touch with you to make sure everything is fine.\n\n5:06 Sure, Sir.\n\n5:07 Sure.\n\n5:07 Thank you so much, Sir.\n\n5:09 Thank you.\n\n5:09 Bye.\n\n5:11 Bye."
        
        if(test){
          conversation = conversation1
        }
        
        const body = {
          "conversation": conversation
        };
        

        // Pass the headers in the options object
        const options = { headers: headers };

        // Make the POST request with options
        return this.http.post('https://kameda01flaskapi01aj.azurewebsites.net/summarize', body, options).pipe(
          catchError((error: HttpErrorResponse) => {
            if (error.status === 400) {
              return 'error';
            }
            return 'error';
          })
        );
      })
    );
  }
}
